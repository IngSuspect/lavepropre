-- Script SQL pour créer la structure de base de données Supabase
-- À exécuter dans le SQL Editor de votre projet Supabase

-- 1. Table des utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(50) DEFAULT 'employee',
    permissions JSONB DEFAULT '{}',
    actif BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Table des clients
CREATE TABLE IF NOT EXISTS clients (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code_client VARCHAR(50) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    telephone VARCHAR(20) NOT NULL,
    adresse TEXT NOT NULL,
    email VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Table des articles
CREATE TABLE IF NOT EXISTS articles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code_article VARCHAR(50) UNIQUE NOT NULL,
    designation VARCHAR(255) NOT NULL,
    prix NUMERIC(10,2) NOT NULL,
    services_personnalises JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Table des commandes
CREATE TABLE IF NOT EXISTS commandes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero_commande VARCHAR(50) UNIQUE NOT NULL,
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    date_commande DATE NOT NULL,
    statut VARCHAR(50) DEFAULT 'en_cours',
    total NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Table de liaison articles-commandes
CREATE TABLE IF NOT EXISTS articles_commandes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    commande_id UUID REFERENCES commandes(id) ON DELETE CASCADE,
    article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
    quantite INTEGER NOT NULL DEFAULT 1,
    prix_unitaire NUMERIC(10,2) NOT NULL,
    services_utilises JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. Table des factures
CREATE TABLE IF NOT EXISTS factures (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero_facture VARCHAR(50) UNIQUE NOT NULL,
    commande_id UUID REFERENCES commandes(id) ON DELETE CASCADE,
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    date_facture DATE NOT NULL,
    montant_total NUMERIC(10,2) NOT NULL,
    statut_paiement VARCHAR(50) DEFAULT 'non_paye',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Insertion de données de test
INSERT INTO utilisateurs (nom, prenom, email, role, permissions) VALUES
('Admin', 'System', 'admin@pressing.gn', 'admin', '{"gestion_utilisateurs": true, "gestion_clients": true, "gestion_articles": true, "gestion_commandes": true, "facturation": true, "settings": true}'),
('Manager', 'Principal', 'manager@pressing.gn', 'manager', '{"gestion_clients": true, "gestion_articles": true, "gestion_commandes": true, "facturation": true}'),
('Employee', 'Standard', 'employee@pressing.gn', 'employee', '{"gestion_clients": true, "gestion_commandes": true}');

INSERT INTO articles (code_article, designation, prix, services_personnalises) VALUES
('ART001', 'Chemise', 5000, '{"nettoyage_sec": 3000, "repassage": 2000, "pliage": 1000}'),
('ART002', 'Pantalon', 9000, '{"nettoyage_sec": 6000, "repassage": 3000, "pliage": 1500}'),
('ART003', 'Robe', 12000, '{"nettoyage_sec": 8000, "repassage": 4000, "pliage": 2000}'),
('ART004', 'Costume complet', 25000, '{"nettoyage_sec": 15000, "repassage": 8000, "pliage": 3000}'),
('ART005', 'Veste', 15000, '{"nettoyage_sec": 10000, "repassage": 5000, "pliage": 2500}');

INSERT INTO clients (code_client, nom, prenom, telephone, adresse, email) VALUES
('CLI001', 'Diallo', 'Mamadou', '+224 622 123 456', 'Kaloum, Conakry', 'mamadou.diallo@email.gn'),
('CLI002', 'Camara', 'Fatoumata', '+224 664 789 012', 'Ratoma, Conakry', 'fatoumata.camara@email.gn'),
('CLI003', 'Barry', 'Ibrahima', '+224 655 345 678', 'Matam, Conakry', 'ibrahima.barry@email.gn');

-- Activation de Row Level Security (RLS)
ALTER TABLE utilisateurs ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE commandes ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles_commandes ENABLE ROW LEVEL SECURITY;
ALTER TABLE factures ENABLE ROW LEVEL SECURITY;

-- Politiques RLS basiques
CREATE POLICY "Permettre toutes les opérations" ON clients FOR ALL USING (true);
CREATE POLICY "Permettre toutes les opérations" ON articles FOR ALL USING (true);
CREATE POLICY "Permettre toutes les opérations" ON commandes FOR ALL USING (true);
CREATE POLICY "Permettre toutes les opérations" ON articles_commandes FOR ALL USING (true);
CREATE POLICY "Permettre toutes les opérations" ON factures FOR ALL USING (true);
CREATE POLICY "Permettre toutes les opérations" ON utilisateurs FOR ALL USING (true);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_clients_code ON clients(code_client);
CREATE INDEX IF NOT EXISTS idx_articles_code ON articles(code_article);
CREATE INDEX IF NOT EXISTS idx_commandes_numero ON commandes(numero_commande);
CREATE INDEX IF NOT EXISTS idx_commandes_client ON commandes(client_id);
CREATE INDEX IF NOT EXISTS idx_factures_numero ON factures(numero_facture);
CREATE INDEX IF NOT EXISTS idx_factures_commande ON factures(commande_id);