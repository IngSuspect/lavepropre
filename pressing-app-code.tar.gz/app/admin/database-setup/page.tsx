'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { CheckCircle, AlertCircle, Loader2, Database, Copy, ExternalLink } from 'lucide-react'
import { supabase } from '@/app/lib/supabase'

export default function DatabaseSetupPage() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const [progress, setProgress] = useState(0)

  // SQL pour créer toutes les tables
  const SQL_SETUP = `
-- Créer la table utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  role VARCHAR(50) DEFAULT 'employee',
  permissions JSONB DEFAULT '{}',
  actif BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Créer la table clients
CREATE TABLE IF NOT EXISTS clients (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  code_client VARCHAR(50) UNIQUE NOT NULL,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  telephone VARCHAR(20) NOT NULL,
  adresse TEXT NOT NULL,
  email VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Créer la table articles
CREATE TABLE IF NOT EXISTS articles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  code_article VARCHAR(50) UNIQUE NOT NULL,
  designation VARCHAR(255) NOT NULL,
  prix NUMERIC(10,2) NOT NULL,
  services_personnalises JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Créer la table commandes
CREATE TABLE IF NOT EXISTS commandes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  numero_commande VARCHAR(50) UNIQUE NOT NULL,
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  date_commande DATE NOT NULL,
  statut VARCHAR(50) DEFAULT 'en_cours',
  total NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Créer la table articles_commandes (relation many-to-many)
CREATE TABLE IF NOT EXISTS articles_commandes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  commande_id UUID REFERENCES commandes(id) ON DELETE CASCADE,
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  quantite INTEGER NOT NULL DEFAULT 1,
  prix_unitaire NUMERIC(10,2) NOT NULL,
  services_utilises JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Créer la table factures
CREATE TABLE IF NOT EXISTS factures (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  numero_facture VARCHAR(50) UNIQUE NOT NULL,
  commande_id UUID REFERENCES commandes(id) ON DELETE CASCADE,
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  date_facture DATE NOT NULL,
  montant_total NUMERIC(10,2) NOT NULL,
  statut_paiement VARCHAR(50) DEFAULT 'non_paye',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Insérer des données de test pour les articles
INSERT INTO articles (code_article, designation, prix) VALUES
  ('ART001', 'Chemise', 5000),
  ('ART002', 'Pantalon', 9000),
  ('ART003', 'Robe', 12000),
  ('ART004', 'Costume', 25000),
  ('ART005', 'Veste', 15000)
ON CONFLICT (code_article) DO NOTHING;

-- Insérer des données de test pour les clients
INSERT INTO clients (code_client, nom, prenom, telephone, adresse, email) VALUES
  ('CLI001', 'Diallo', 'Mamadou', '+224 622 123 456', 'Kaloum, Conakry', 'mamadou.diallo@email.gn'),
  ('CLI002', 'Camara', 'Fatoumata', '+224 664 789 012', 'Ratoma, Conakry', 'fatoumata.camara@email.gn'),
  ('CLI003', 'Bah', 'Amadou', '+224 655 234 567', 'Matam, Conakry', 'amadou.bah@email.gn')
ON CONFLICT (code_client) DO NOTHING;

-- Insérer un utilisateur administrateur de test
INSERT INTO utilisateurs (nom, prenom, email, role, permissions, actif) VALUES
  ('Admin', 'Système', 'admin@pressing.gn', 'admin', '{"all": true}', true)
ON CONFLICT (email) DO NOTHING;
`

  const setupDatabase = async () => {
    console.log('🚀 Début de l\'initialisation de la base de données')
    setStatus('loading')
    setProgress(10)
    setMessage('Connexion à Supabase...')
    
    try {
      // Test de connexion basique
      setMessage('Test de la connexion...')
      setProgress(20)
      
      const { error: healthCheck } = await supabase
        .from('clients')
        .select('count')
        .limit(1)

      setMessage('Vérification des permissions...')
      setProgress(40)
      
      // Si pas d'erreur de permissions, on essaie d'insérer des données de test
      setMessage('Insertion des données de test...')
      setProgress(60)
      
      // Insérer des articles de test
      const { error: articlesError } = await supabase
        .from('articles')
        .upsert([
          { code_article: 'ART001', designation: 'Chemise', prix: 5000 },
          { code_article: 'ART002', designation: 'Pantalon', prix: 9000 },
          { code_article: 'ART003', designation: 'Robe', prix: 12000 }
        ], { onConflict: 'code_article' })

      if (articlesError && !articlesError.message.includes('relation "articles" does not exist')) {
        throw articlesError
      }

      // Insérer des clients de test
      const { error: clientsError } = await supabase
        .from('clients')
        .upsert([
          { 
            code_client: 'CLI001', 
            nom: 'Diallo', 
            prenom: 'Mamadou', 
            telephone: '+224 622 123 456', 
            adresse: 'Kaloum, Conakry',
            email: 'mamadou.diallo@email.gn'
          },
          { 
            code_client: 'CLI002', 
            nom: 'Camara', 
            prenom: 'Fatoumata', 
            telephone: '+224 664 789 012', 
            adresse: 'Ratoma, Conakry',
            email: 'fatoumata.camara@email.gn'
          }
        ], { onConflict: 'code_client' })

      if (clientsError && !clientsError.message.includes('relation "clients" does not exist')) {
        throw clientsError
      }

      setProgress(90)
      setMessage('Finalisation...')
      
      setProgress(100)
      setMessage('✅ Configuration terminée! Les données de test ont été ajoutées.')
      setStatus('success')
      console.log('🎉 Base de données configurée avec succès!')

    } catch (error: any) {
      console.error('❌ Erreur lors de l\'initialisation:', error)
      setStatus('error')
      
      let errorMessage = 'Erreur inconnue'
      
      if (error?.message?.includes('relation') && error?.message?.includes('does not exist')) {
        errorMessage = 'Les tables n\'existent pas encore. Utilisez le SQL Editor de Supabase pour les créer.'
      } else if (error?.message?.includes('permission')) {
        errorMessage = 'Permissions insuffisantes. Vérifiez les RLS policies dans Supabase.'
      } else if (error?.message?.includes('network')) {
        errorMessage = 'Problème de connexion réseau. Vérifiez votre connexion internet.'
      } else if (error?.message) {
        errorMessage = error.message
      }
      
      setMessage(`❌ ${errorMessage}`)
    }
  }

  const testConnection = async () => {
    console.log('🔍 Test de connexion Supabase')
    setStatus('loading')
    setMessage('Test de connexion à Supabase...')
    setProgress(50)

    try {
      // Test avec une requête simple
      const { data, error, count } = await supabase
        .from('clients')
        .select('*', { count: 'exact' })
        .limit(5)

      if (error) {
        console.error('❌ Erreur test connexion:', error)
        throw error
      }

      console.log('✅ Connexion réussie, données:', data)
      setStatus('success')
      setProgress(100)
      setMessage(`✅ Connexion réussie! ${count || 0} clients trouvés dans la base.`)
    } catch (error: any) {
      console.error('❌ Erreur test connexion:', error)
      setStatus('error')
      setProgress(0)
      
      let errorMessage = 'Erreur de connexion inconnue'
      
      if (error?.message?.includes('relation') && error?.message?.includes('does not exist')) {
        errorMessage = 'Table "clients" introuvable. Exécutez d\'abord le script SQL pour créer les tables.'
      } else if (error?.message?.includes('permission')) {
        errorMessage = 'Accès refusé. Vérifiez les permissions RLS dans Supabase.'
      } else if (error?.message?.includes('network')) {
        errorMessage = 'Problème réseau. Vérifiez votre connexion.'
      } else if (error?.message) {
        errorMessage = error.message
      }
      
      setMessage(`❌ ${errorMessage}`)
    }
  }

  const copySQL = () => {
    navigator.clipboard.writeText(SQL_SETUP)
    setMessage('📋 SQL copié dans le presse-papiers!')
    setTimeout(() => setMessage(''), 2000)
  }

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Configuration Base de Données</h1>
        <p className="text-gray-600">Configurez votre base de données Supabase pour votre application de pressing</p>
      </div>

      <div className="grid gap-6">
        {/* Méthode recommandée : SQL Editor */}
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700">
              <Database className="h-5 w-5" />
              Méthode Recommandée : SQL Editor Supabase
            </CardTitle>
            <CardDescription className="text-blue-600">
              La méthode la plus fiable pour créer vos tables
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg border border-blue-200">
              <h4 className="font-semibold text-gray-900 mb-2">Instructions :</h4>
              <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700">
                <li>Ouvrez votre projet Supabase dans le navigateur</li>
                <li>Allez dans l'onglet "SQL Editor"</li>
                <li>Copiez le script SQL ci-dessous</li>
                <li>Collez-le dans l'éditeur et exécutez-le</li>
                <li>Revenez ici pour tester la connexion</li>
              </ol>
            </div>
            
            <div className="flex gap-2">
              <Button onClick={copySQL} className="bg-blue-600 hover:bg-blue-700">
                <Copy className="h-4 w-4 mr-2" />
                Copier le Script SQL
              </Button>
              <Button 
                variant="outline" 
                onClick={() => window.open('https://supabase.com/dashboard/project/xiaweiotalfkxqiseyeh/sql', '_blank')}
                className="border-blue-300 text-blue-700 hover:bg-blue-50"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Ouvrir SQL Editor
              </Button>
            </div>

            {/* Script SQL affiché */}
            <details className="bg-gray-50 rounded-lg">
              <summary className="p-3 cursor-pointer font-medium text-gray-700 hover:bg-gray-100 rounded-lg">
                📄 Voir le Script SQL Complet
              </summary>
              <pre className="p-4 text-xs bg-gray-900 text-green-400 rounded-b-lg overflow-x-auto">
                <code>{SQL_SETUP}</code>
              </pre>
            </details>
          </CardContent>
        </Card>

        {/* Test automatique */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              Configuration Automatique (Limitée)
            </CardTitle>
            <CardDescription>
              Tentative d'ajout des données de test si les tables existent
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={setupDatabase}
              disabled={status === 'loading'}
              className="w-full"
              size="lg"
            >
              {status === 'loading' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Ajouter les Données de Test
            </Button>

            {status === 'loading' && (
              <div className="space-y-2">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-600 text-center">{message}</p>
              </div>
            )}

            {status === 'success' && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}

            {status === 'error' && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Test de connexion */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-blue-500" />
              Test de Connexion
            </CardTitle>
            <CardDescription>
              Vérifiez que votre base de données fonctionne correctement
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={testConnection}
              disabled={status === 'loading'}
              variant="outline"
              className="w-full"
            >
              {status === 'loading' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Tester la Connexion
            </Button>
          </CardContent>
        </Card>

        {/* Informations utiles */}
        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-800">ℹ️ Informations Importantes</CardTitle>
          </CardHeader>
          <CardContent className="text-yellow-700 space-y-2">
            <p>• <strong>Projet Supabase :</strong> xiaweiotalfkxqiseyeh</p>
            <p>• <strong>Dashboard :</strong> <a href="https://supabase.com/dashboard/project/xiaweiotalfkxqiseyeh" target="_blank" className="text-blue-600 hover:underline">https://supabase.com/dashboard/project/xiaweiotalfkxqiseyeh</a></p>
            <p>• <strong>SQL Editor :</strong> <a href="https://supabase.com/dashboard/project/xiaweiotalfkxqiseyeh/sql" target="_blank" className="text-blue-600 hover:underline">Accès direct</a></p>
            <p>• <strong>Statut :</strong> Configuration en cours</p>
            <p>• <strong>Tables à créer :</strong> utilisateurs, clients, articles, commandes, factures</p>
            <p>• <strong>RLS (Row Level Security) :</strong> Peut nécessiter une configuration pour certaines opérations</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}