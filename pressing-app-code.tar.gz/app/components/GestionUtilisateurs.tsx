'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../../components/ui/dialog';
import { sessionActive } from '../lib/mock-data';
import { ROLES_LABELS } from '../types/pressing';
import { Plus, Search, Edit, Trash2, Users, Shield, UserCheck, UserX, Calendar } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';

export default function GestionUtilisateurs() {
  const [utilisateurs, setUtilisateurs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [recherche, setRecherche] = useState('');
  const [utilisateurModale, setUtilisateurModale] = useState<any | null>(null);
  const [modeCreation, setModeCreation] = useState(false);
  const { toast } = useToast();

  // Charger les utilisateurs depuis l'API
  useEffect(() => {
    loadUtilisateurs();
  }, []);

  const loadUtilisateurs = async () => {
    try {
      console.log('Loading utilisateurs from API...');
      setLoading(true);
      
      const response = await fetch('/api/utilisateurs');
      if (!response.ok) {
        throw new Error('Erreur lors du chargement des utilisateurs');
      }
      
      const data = await response.json();
      console.log('Utilisateurs loaded from API:', data);
      setUtilisateurs(data);
    } catch (error) {
      console.error('Erreur lors du chargement des utilisateurs:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les utilisateurs",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  console.log('GestionUtilisateurs rendered');

  const peutModifierUtilisateurs = () => {
    return sessionActive?.utilisateur.role === 'admin';
  };

  const utilisateursFiltrés = utilisateurs.filter(utilisateur =>
    `${utilisateur.prenom || ''} ${utilisateur.nom || ''}`.toLowerCase().includes(recherche.toLowerCase()) ||
    (utilisateur.email || '').toLowerCase().includes(recherche.toLowerCase()) ||
    (utilisateur.role || '').toLowerCase().includes(recherche.toLowerCase())
  );

  const ouvrirModaleCreation = () => {
    setUtilisateurModale({
      id: '',
      nom: '',
      prenom: '',
      email: '',
      mot_de_passe: '',
      role: 'employe',
      statut: 'actif',
      permissions: []
    });
    setModeCreation(true);
  };

  const ouvrirModaleModification = (utilisateur: any) => {
    setUtilisateurModale({ ...utilisateur });
    setModeCreation(false);
  };

  const fermerModale = () => {
    setUtilisateurModale(null);
    setModeCreation(false);
  };

  const sauvegarderUtilisateur = () => {
    if (!utilisateurModale) return;

    console.log('Sauvegarde utilisateur:', utilisateurModale);

    if (modeCreation) {
      const nouvelUtilisateur = {
        ...utilisateurModale,
        id: Date.now().toString(),
        created_at: new Date()
      };
      setUtilisateurs([...utilisateurs, nouvelUtilisateur]);
      toast({
        title: "Utilisateur créé",
        description: `${nouvelUtilisateur.prenom} ${nouvelUtilisateur.nom} a été ajouté avec succès.`,
      });
    } else {
      setUtilisateurs(utilisateurs.map(u => 
        u.id === utilisateurModale.id ? utilisateurModale : u
      ));
      toast({
        title: "Utilisateur modifié",
        description: `${utilisateurModale.prenom} ${utilisateurModale.nom} a été mis à jour.`,
      });
    }

    fermerModale();
  };

  const changerStatutUtilisateur = (id: string) => {
    const utilisateur = utilisateurs.find(u => u.id === id);
    if (utilisateur) {
      const nouveauStatut = utilisateur.statut === 'actif' ? 'inactif' : 'actif';
      setUtilisateurs(utilisateurs.map(u => 
        u.id === id ? { ...u, statut: nouveauStatut } : u
      ));
      
      toast({
        title: `Utilisateur ${nouveauStatut}`,
        description: `${utilisateur.prenom} ${utilisateur.nom} est maintenant ${nouveauStatut}.`,
      });
    }
  };

  const supprimerUtilisateur = (id: string) => {
    const utilisateur = utilisateurs.find(u => u.id === id);
    if (utilisateur && utilisateur.role !== 'admin') {
      setUtilisateurs(utilisateurs.filter(u => u.id !== id));
      toast({
        title: "Utilisateur supprimé",
        description: `${utilisateur.prenom} ${utilisateur.nom} a été supprimé.`,
        variant: "destructive"
      });
    }
  };

  if (!peutModifierUtilisateurs()) {
    return (
      <div className="p-6">
        <Card className="glass-effect border-0 card-hover">
          <CardContent className="p-8 text-center">
            <Shield className="h-16 w-16 mx-auto mb-4 text-orange-500" />
            <h3 className="text-xl font-semibold text-pressing-text mb-2">
              Accès restreint
            </h3>
            <p className="text-gray-600">
              Seuls les administrateurs peuvent gérer les utilisateurs.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
            Gestion des utilisateurs
          </h2>
          <p className="text-gray-600 mt-2 text-lg">Gérez les accès et permissions</p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button 
              onClick={ouvrirModaleCreation}
              className="gradient-button w-full sm:w-auto text-white border-0 shadow-lg"
            >
              <Plus className="h-4 w-4 mr-2" />
              Nouvel utilisateur
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {modeCreation ? 'Créer un utilisateur' : 'Modifier l\'utilisateur'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="prenom">Prénom</Label>
                  <Input
                    id="prenom"
                    value={utilisateurModale?.prenom || ''}
                    onChange={(e) => setUtilisateurModale(prev => prev ? { ...prev, prenom: e.target.value } : null)}
                    className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nom">Nom</Label>
                  <Input
                    id="nom"
                    value={utilisateurModale?.nom || ''}
                    onChange={(e) => setUtilisateurModale(prev => prev ? { ...prev, nom: e.target.value } : null)}
                    className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={utilisateurModale?.email || ''}
                  onChange={(e) => setUtilisateurModale(prev => prev ? { ...prev, email: e.target.value } : null)}
                  className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="motDePasse">Mot de passe</Label>
                <Input
                  id="motDePasse"
                  type="password"
                  value={utilisateurModale?.motDePasse || ''}
                  onChange={(e) => setUtilisateurModale(prev => prev ? { ...prev, motDePasse: e.target.value } : null)}
                  className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  placeholder={modeCreation ? "Mot de passe" : "Laisser vide pour ne pas modifier"}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Rôle</Label>
                <select
                  id="role"
                  value={utilisateurModale?.role || 'employe'}
                  onChange={(e) => setUtilisateurModale(prev => prev ? { ...prev, role: e.target.value as any } : null)}
                  className="w-full px-3 py-2 border border-pressing-primary/20 rounded-xl bg-white/70 focus:outline-none focus:ring-2 focus:ring-pressing-primary backdrop-blur-sm"
                >
                  <option value="employe">Employé</option>
                  <option value="gestionnaire">Gestionnaire</option>
                  <option value="admin">Administrateur</option>
                </select>
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={fermerModale} variant="outline" className="flex-1">
                  Annuler
                </Button>
                <Button onClick={sauvegarderUtilisateur} className="flex-1 gradient-button text-white">
                  {modeCreation ? 'Créer' : 'Modifier'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Recherche */}
      <Card className="glass-effect border-0 card-hover">
        <CardContent className="p-6">
          <div className="relative">
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 p-1 bg-pressing-primary/10 rounded-lg">
              <Search className="h-4 w-4 text-pressing-primary" />
            </div>
            <Input
              type="text"
              placeholder="Rechercher par nom, email ou rôle..."
              className="pl-12 border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
              value={recherche}
              onChange={(e) => setRecherche(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Liste des utilisateurs */}
      <div className="grid gap-6">
        {utilisateursFiltrés.map((utilisateur) => (
          <Card key={utilisateur.id} className="card-hover glass-effect border-0">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-pressing-primary to-pressing-accent rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-pressing-text">
                        {utilisateur.prenom} {utilisateur.nom}
                      </h3>
                      <p className="text-sm text-gray-600">{utilisateur.email}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge 
                          className={
                            utilisateur.role === 'admin' 
                              ? 'bg-red-100 text-red-800 border-red-200' 
                              : utilisateur.role === 'gestionnaire'
                              ? 'bg-blue-100 text-blue-800 border-blue-200'
                              : 'bg-green-100 text-green-800 border-green-200'
                          }
                          variant="outline"
                        >
                          {ROLES_LABELS[utilisateur.role]}
                        </Badge>
                        <Badge 
                          className={
                            utilisateur.statut === 'actif' 
                              ? 'bg-green-100 text-green-800 border-green-200' 
                              : 'bg-gray-100 text-gray-800 border-gray-200'
                          }
                          variant="outline"
                        >
                          {utilisateur.statut}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>Créé: {utilisateur.created_at 
                        ? new Date(utilisateur.created_at).toLocaleDateString('fr-FR')
                        : 'Non disponible'
                      }</span>
                    </div>

                    <div className="flex items-center gap-1 text-gray-600">
                      <UserCheck className="h-4 w-4" />
                      <span>
                        Dernière connexion: {utilisateur.derniere_connexion 
                          ? new Date(utilisateur.derniere_connexion).toLocaleDateString('fr-FR')
                          : 'Jamais'
                        }
                      </span>
                    </div>
                  </div>

                  <div className="mt-3">
                    <p className="text-sm font-medium text-gray-700 mb-1">Permissions:</p>
                    <div className="flex flex-wrap gap-1">
                      {utilisateur.permissions && utilisateur.permissions.length > 0 ? (
                        <>
                          {utilisateur.permissions.slice(0, 3).map((permission, index) => (
                            <span
                              key={permission.id || index}
                              className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-pressing-secondary text-pressing-primary"
                            >
                              {permission.nom || permission}
                            </span>
                          ))}
                          {utilisateur.permissions.length > 3 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600">
                              +{utilisateur.permissions.length - 3} autres
                            </span>
                          )}
                        </>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600">
                          Permissions par défaut
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="lg:min-w-[200px] flex flex-col gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => ouvrirModaleModification(utilisateur)}
                    className="w-full border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white rounded-xl transition-all"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Modifier
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => changerStatutUtilisateur(utilisateur.id)}
                    className={`w-full rounded-xl transition-all ${
                      utilisateur.statut === 'actif'
                        ? 'border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white'
                        : 'border-green-500 text-green-500 hover:bg-green-500 hover:text-white'
                    }`}
                  >
                    {utilisateur.statut === 'actif' ? (
                      <>
                        <UserX className="h-4 w-4 mr-1" />
                        Désactiver
                      </>
                    ) : (
                      <>
                        <UserCheck className="h-4 w-4 mr-1" />
                        Activer
                      </>
                    )}
                  </Button>

                  {utilisateur.role !== 'admin' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => supprimerUtilisateur(utilisateur.id)}
                      className="w-full border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-all"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Supprimer
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {utilisateursFiltrés.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Search className="h-12 w-12 mx-auto mb-4" />
              <p className="text-lg font-medium">Aucun utilisateur trouvé</p>
              <p className="text-sm">Essayez de modifier vos critères de recherche</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}