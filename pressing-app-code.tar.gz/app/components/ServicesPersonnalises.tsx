'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Switch } from '../../components/ui/switch';
import { Badge } from '../../components/ui/badge';
import { ServicePersonnalise, SERVICES_DEFAULTS } from '../types/pressing';
import { Settings, Plus, Save, Trash2, DollarSign } from 'lucide-react';

interface ServicesPersonnalisesProps {
  services: ServicePersonnalise[];
  onChange: (services: ServicePersonnalise[]) => void;
}

export default function ServicesPersonnalises({ services, onChange }: ServicesPersonnalisesProps) {
  console.log('ServicesPersonnalises rendered with services:', services);

  const [isEditing, setIsEditing] = useState(false);

  // Créer la liste complète des services avec les prix par défaut ou personnalisés
  const getServicesComplets = (): ServicePersonnalise[] => {
    return SERVICES_DEFAULTS.map(serviceDefaut => {
      const servicePersonnalise = services.find(s => s.serviceId === serviceDefaut.id);
      return servicePersonnalise || {
        serviceId: serviceDefaut.id,
        nom: serviceDefaut.nom,
        prixPersonnalise: serviceDefaut.prix,
        actif: true
      };
    });
  };

  const servicesComplets = getServicesComplets();

  const handlePrixChange = (serviceId: string, nouveauPrix: number) => {
    console.log('Changing price for service', serviceId, 'to', nouveauPrix);
    
    const nouveauxServices = servicesComplets.map(service => 
      service.serviceId === serviceId 
        ? { ...service, prixPersonnalise: nouveauPrix }
        : service
    );
    
    // Ne garder que les services qui sont différents du prix par défaut ou inactifs
    const servicesModifies = nouveauxServices.filter(service => {
      const serviceDefaut = SERVICES_DEFAULTS.find(s => s.id === service.serviceId);
      return !service.actif || (serviceDefaut && service.prixPersonnalise !== serviceDefaut.prix);
    });
    
    onChange(servicesModifies);
  };

  const handleActivationChange = (serviceId: string, actif: boolean) => {
    console.log('Toggling activation for service', serviceId, 'to', actif);
    
    const nouveauxServices = servicesComplets.map(service => 
      service.serviceId === serviceId 
        ? { ...service, actif }
        : service
    );
    
    // Ne garder que les services qui sont différents du prix par défaut ou inactifs
    const servicesModifies = nouveauxServices.filter(service => {
      const serviceDefaut = SERVICES_DEFAULTS.find(s => s.id === service.serviceId);
      return !service.actif || (serviceDefaut && service.prixPersonnalise !== serviceDefaut.prix);
    });
    
    onChange(servicesModifies);
  };

  const resetToDefaults = () => {
    console.log('Resetting services to defaults');
    onChange([]);
    setIsEditing(false);
  };

  return (
    <Card className="border-pressing-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-pressing-primary" />
            Prix des services pour cet article
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
              className="border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white"
            >
              {isEditing ? 'Valider' : 'Personnaliser'}
            </Button>
            {services.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={resetToDefaults}
                className="border-gray-300 text-gray-600 hover:bg-gray-50"
              >
                Réinitialiser
              </Button>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid gap-4">
          {servicesComplets.map((service) => {
            const serviceDefaut = SERVICES_DEFAULTS.find(s => s.id === service.serviceId);
            const estPersonnalise = serviceDefaut && service.prixPersonnalise !== serviceDefaut.prix;
            
            return (
              <div key={service.serviceId} className={`p-4 rounded-lg border transition-all ${
                !service.actif 
                  ? 'bg-gray-50 border-gray-200 opacity-60' 
                  : estPersonnalise 
                    ? 'bg-pressing-secondary border-pressing-primary/30' 
                    : 'bg-white border-gray-200'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={service.actif}
                        onCheckedChange={(checked) => handleActivationChange(service.serviceId, checked)}
                        disabled={!isEditing}
                      />
                      <span className="font-medium">{service.nom}</span>
                    </div>
                    {estPersonnalise && (
                      <Badge variant="outline" className="bg-pressing-primary text-white border-pressing-primary">
                        Personnalisé
                      </Badge>
                    )}
                  </div>
                  
                  {serviceDefaut && (
                    <div className="text-xs text-gray-500">
                      Prix par défaut: {serviceDefaut.prix.toLocaleString()} GNF
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <Label htmlFor={`prix-${service.serviceId}`} className="text-sm">
                      Prix personnalisé (GNF)
                    </Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id={`prix-${service.serviceId}`}
                        type="number"
                        value={service.prixPersonnalise || ''}
                        onChange={(e) => handlePrixChange(service.serviceId, parseInt(e.target.value) || 0)}
                        placeholder="Prix en GNF"
                        disabled={!isEditing || !service.actif}
                        className="pl-10 border-pressing-primary/20 focus:border-pressing-primary"
                      />
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Prix final</div>
                    <div className={`text-xl font-bold ${
                      service.actif ? 'text-pressing-primary' : 'text-gray-400'
                    }`}>
                      {service.actif ? service.prixPersonnalise.toLocaleString() : '0'} GNF
                    </div>
                  </div>
                </div>
                
                {serviceDefaut?.description && (
                  <p className="text-xs text-gray-500 mt-2">{serviceDefaut.description}</p>
                )}
              </div>
            );
          })}
        </div>
        
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start gap-2">
            <div className="w-4 h-4 rounded-full bg-blue-500 flex-shrink-0 mt-0.5"></div>
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">💡 Comment ça marche ?</p>
              <p>Personnalisez les prix des services pour cet article spécifique. Les prix par défaut s'appliquent si vous ne modifiez rien. Désactivez un service si il n'est pas applicable à cet article.</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}