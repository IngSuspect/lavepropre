'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../../components/ui/dialog';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Article, genererCodeArticle, CATEGORIES_ARTICLES, COULEURS_CATEGORIES, ServicePersonnalise } from '../types/pressing';
import { useToast } from '../../hooks/use-toast';
import ServicesPersonnalises from './ServicesPersonnalises';
import { 
  Search, 
  Plus, 
  Shirt, 
  Edit, 
  Archive, 
  ArchiveRestore,
  Package,
  Tags,
  DollarSign,
  Save,
  X,
  Filter,
  Grid3X3,
  List,
  Palette,
  Ruler,
  Calendar
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

export default function ArticlesList() {
  console.log('ArticlesList rendered');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [articles, setArticles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<any | null>(null);
  const { toast } = useToast();
  const [newArticle, setNewArticle] = useState({
    designation: '',
    prix: 0,
    servicesPersonnalises: [] as any[]
  });

  // Charger les articles depuis l'API
  useEffect(() => {
    loadArticles();
  }, []);

  const loadArticles = async () => {
    try {
      console.log('Loading articles from API...');
      setLoading(true);
      
      const response = await fetch('/api/articles');
      if (!response.ok) {
        throw new Error('Erreur lors du chargement des articles');
      }
      
      const data = await response.json();
      console.log('Articles loaded from API:', data);
      setArticles(data);
    } catch (error) {
      console.error('Erreur lors du chargement des articles:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les articles",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredArticles = articles.filter(article => {
    const matchesSearch = 
      article.designation?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.code_article?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Pour l'instant, on ne filtre pas par catégorie car cette info n'est pas en DB
    const matchesCategory = true;
    
    return matchesSearch && matchesCategory;
  });

  // Fonction pour ajouter un nouvel article
  const handleAddArticle = async () => {
    console.log('Adding new article:', newArticle);
    
    if (!newArticle.designation.trim() || newArticle.prix <= 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir au minimum la désignation et le prix",
        variant: "destructive"
      });
      return;
    }

    try {
      // Générer un code unique basé sur le timestamp et un nombre aléatoire
      const timestamp = Date.now().toString().slice(-4);
      const random = Math.floor(Math.random() * 100).toString().padStart(2, '0');
      const uniqueCode = `ART${timestamp}${random}`;
      
      const articleData = {
        code_article: uniqueCode,
        designation: newArticle.designation.trim(),
        prix: newArticle.prix,
        services_personnalises: newArticle.servicesPersonnalises
      };

      const response = await fetch('/api/articles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(articleData),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la création de l\'article');
      }

      const createdArticle = await response.json();
      console.log('Article created successfully:', createdArticle);
      
      toast({
        title: "Succès",
        description: "Article créé avec succès",
      });

      resetForm();
      await loadArticles(); // Recharger la liste
    } catch (error) {
      console.error('Erreur lors de la création de l\'article:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer l'article",
        variant: "destructive"
      });
    }
  };

  // Fonction pour modifier un article
  const handleEditArticle = (article: any) => {
    setEditingArticle(article);
    setNewArticle({
      designation: article.designation,
      prix: article.prix,
      servicesPersonnalises: article.services_personnalises || []
    });
    setIsAddModalOpen(true);
  };

  // Fonction pour sauvegarder les modifications
  const handleSaveEdit = async () => {
    if (!editingArticle) return;
    
    try {
      const updatedData = {
        id: editingArticle.id,
        designation: newArticle.designation.trim(),
        prix: newArticle.prix,
        services_personnalises: newArticle.servicesPersonnalises
      };

      const response = await fetch('/api/articles', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedData),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la mise à jour de l\'article');
      }

      const updatedArticle = await response.json();
      console.log('Article updated successfully:', updatedArticle);
      
      toast({
        title: "Succès",
        description: "Article modifié avec succès",
      });

      resetForm();
      await loadArticles(); // Recharger la liste
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'article:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modifier l'article",
        variant: "destructive"
      });
    }
  };

  // Fonction pour archiver/désarchiver un article
  const toggleArchiveArticle = async (articleId: string) => {
    try {
      const article = articles.find(a => a.id === articleId);
      if (!article) return;

      const updatedData = {
        ...article,
        actif: !article.actif
      };

      const response = await fetch('/api/articles', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedData),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de l\'archivage de l\'article');
      }

      toast({
        title: "Succès",
        description: `Article ${article.actif ? 'archivé' : 'désarchivé'} avec succès`,
      });

      await loadArticles(); // Recharger la liste
    } catch (error) {
      console.error('Erreur lors de l\'archivage de l\'article:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modifier l'article",
        variant: "destructive"
      });
    }
  };

  // Fonction pour réinitialiser le formulaire
  const resetForm = () => {
    setNewArticle({
      designation: '',
      prix: 0,
      servicesPersonnalises: []
    });
    setEditingArticle(null);
    setIsAddModalOpen(false);
  };

  // Calcul des statistiques
  const stats = {
    totalArticles: articles.length,
    articlesArchives: 0, // Pas de gestion d'archivage dans le schéma actuel
    prixMoyen: articles.reduce((sum, a) => sum + (a.prix || 0), 0) / Math.max(articles.length, 1),
    categoriesCount: Object.entries(CATEGORIES_ARTICLES).map(([key, label]) => ({
      key,
      label,
      count: 0 // Pas de catégories dans le schéma actuel
    }))
  };

  const getCategoryIcon = (categorie: string) => {
    switch (categorie) {
      case 'vetements': return Shirt;
      case 'accessoires': return Tags;
      case 'chaussures': return Package;
      case 'cuir': return Archive;
      case 'linge': return Grid3X3;
      default: return Package;
    }
  };

  // Helper function to safely get category colors
  const getCategoryColor = (categorie: string) => {
    return COULEURS_CATEGORIES[categorie] || 'border-gray-200 text-gray-600';
  };

  // Helper function to safely get category background
  const getCategoryBackground = (categorie: string) => {
    const color = getCategoryColor(categorie);
    return color.replace('text-', 'bg-').replace('border-', '').split(' ')[0] + '/20';
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-8">
          <div className="text-pressing-primary">Chargement des articles...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
            Articles
          </h2>
          <p className="text-gray-600 mt-2 text-lg">Gérez votre catalogue d'articles avec style</p>
        </div>
        <Button 
          onClick={() => setIsAddModalOpen(true)}
          className="gradient-button w-full sm:w-auto text-white border-0 shadow-lg"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nouvel article
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="card-hover bg-gradient-to-br from-pressing-primary to-pressing-accent text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm">Total articles</p>
                <p className="text-2xl font-bold">{stats.totalArticles}</p>
              </div>
              <Package className="h-8 w-8 text-white/80" />
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-mint to-pressing-accent text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm">Prix moyen</p>
                <p className="text-xl font-bold">{stats.prixMoyen.toFixed(0)} GNF</p>
              </div>
              <DollarSign className="h-8 w-8 text-white/80" />
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-accent2 to-orange-400 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm">Catégories</p>
                <p className="text-2xl font-bold">{stats.categoriesCount.filter(c => c.count > 0).length}</p>
              </div>
              <Filter className="h-8 w-8 text-white/80" />
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-purple-500 to-pressing-primary text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm">Archivés</p>
                <p className="text-2xl font-bold">{stats.articlesArchives}</p>
              </div>
              <Archive className="h-8 w-8 text-white/80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Controls */}
      <Card className="glass-effect border-0">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Rechercher par désignation, code, description, marque, couleur..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            


            <div className="flex gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Articles Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredArticles.map((article) => {
            const CategoryIcon = Package; // Icône par défaut
            
            return (
              <Card key={article.id} className="card-hover glass-effect border-0">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-pressing-primary/10">
                        <CategoryIcon className="h-5 w-5 text-pressing-primary" />
                      </div>
                      <Badge className="border-pressing-primary text-pressing-primary" variant="outline">
                        Article
                      </Badge>
                    </div>
                    <span className="text-xs font-mono bg-pressing-secondary text-pressing-primary px-2 py-1 rounded">
                      {article.code_article}
                    </span>
                  </div>
                  <CardTitle className="text-lg leading-tight">
                    {article.designation}
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="text-center p-3 bg-gradient-to-r from-pressing-background to-pressing-secondary rounded-lg">
                    <p className="text-2xl font-bold text-pressing-primary">
                      {article.prix.toLocaleString()} GNF
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>Créé le {new Date(article.created_at).toLocaleDateString('fr-FR')}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditArticle(article)}
                      className="flex-1 border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Modifier
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        // List View
        <div className="space-y-4">
          {filteredArticles.map((article) => {
            const CategoryIcon = Package;
            
            return (
              <Card key={article.id} className="card-hover glass-effect border-0">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-pressing-primary/10">
                      <CategoryIcon className="h-6 w-6 text-pressing-primary" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg truncate">{article.designation}</h3>
                        <span className="text-xs font-mono bg-pressing-secondary text-pressing-primary px-2 py-1 rounded">
                          {article.code_article}
                        </span>
                        <Badge className="border-pressing-primary text-pressing-primary" variant="outline">
                          Article
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>Créé le {new Date(article.created_at).toLocaleDateString('fr-FR')}</span>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-2xl font-bold text-pressing-primary mb-2">
                        {article.prix.toLocaleString()} GNF
                      </p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditArticle(article)}
                          className="border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white"
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Modifier
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Empty State */}
      {filteredArticles.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Package className="h-12 w-12 mx-auto mb-4" />
              <p className="text-lg font-medium">Aucun article trouvé</p>
              <p className="text-sm">Essayez de modifier vos critères de recherche ou ajoutez un nouvel article</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Article Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-[900px] glass-effect border-0 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent flex items-center gap-2">
              <div className="p-2 bg-pressing-primary/10 rounded-lg">
                {editingArticle ? <Edit className="h-5 w-5 text-pressing-primary" /> : <Plus className="h-5 w-5 text-pressing-primary" />}
              </div>
              {editingArticle ? 'Modifier l\'article' : 'Nouvel Article'}
            </DialogTitle>
            <DialogDescription className="text-gray-600">
              {editingArticle ? 'Modifiez les informations de l\'article' : 'Ajoutez un nouvel article à votre catalogue'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="designation" className="text-sm font-medium text-gray-700">
                  Désignation *
                </Label>
                <Input
                  id="designation"
                  value={newArticle.designation}
                  onChange={(e) => setNewArticle(prev => ({ ...prev, designation: e.target.value }))}
                  placeholder="Ex: Chemise homme classique"
                  className="border-pressing-primary/20 focus:border-pressing-primary"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="prix" className="text-sm font-medium text-gray-700">
                  Prix (GNF) *
                </Label>
                <Input
                  id="prix"
                  type="number"
                  value={newArticle.prix || ''}
                  onChange={(e) => setNewArticle(prev => ({ ...prev, prix: parseInt(e.target.value) || 0 }))}
                  placeholder="Ex: 5000"
                  className="border-pressing-primary/20 focus:border-pressing-primary"
                />
              </div>
            </div>
            
            {/* Services personnalisés */}
            <div className="mt-6">
              <ServicesPersonnalises
                services={newArticle.servicesPersonnalises}
                onChange={(services) => setNewArticle(prev => ({ ...prev, servicesPersonnalises: services }))}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button
              type="button"
              onClick={editingArticle ? handleSaveEdit : handleAddArticle}
              className="gradient-button text-white border-0 shadow-lg"
            >
              <Save className="h-4 w-4 mr-2" />
              {editingArticle ? 'Sauvegarder' : 'Créer l\'article'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}