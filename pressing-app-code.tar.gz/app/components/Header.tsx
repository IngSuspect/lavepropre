'use client';

import React from 'react';
import { Menu, Search, Bell, User, LogOut } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Avatar, AvatarFallback } from '../../components/ui/avatar';
import { Badge } from '../../components/ui/badge';
import { Utilisateur, ROLES_LABELS } from '../types/pressing';

interface HeaderProps {
  onMenuToggle: () => void;
  title: string;
  utilisateur: Utilisateur;
  onDeconnexion: () => void;
}

export default function Header({ onMenuToggle, title, utilisateur, onDeconnexion }: HeaderProps) {
  console.log('Header rendered - title:', title, 'utilisateur:', utilisateur.prenom);
  
  return (
    <header className="bg-white border-b border-gray-200 px-4 lg:px-6 h-16 flex items-center justify-between">
      {/* Left section */}
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={onMenuToggle}
          className="lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        <div>
          <h1 className="text-xl font-semibold text-pressing-text">{title}</h1>
        </div>
      </div>

      {/* Center section - Search */}
      <div className="hidden md:flex flex-1 max-w-lg mx-8">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Rechercher un client, une commande..."
            className="pl-10 bg-pressing-background border-gray-200 focus:border-pressing-primary"
          />
        </div>
      </div>

      {/* Right section */}
      <div className="flex items-center space-x-3">
        {/* Search button for mobile */}
        <Button variant="ghost" size="sm" className="md:hidden">
          <Search className="h-5 w-5" />
        </Button>
        
        {/* Notifications */}
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute -top-1 -right-1 h-3 w-3 bg-pressing-accent rounded-full"></span>
        </Button>
        
        {/* User Profile */}
        <div className="flex items-center space-x-3 border-l border-gray-200 pl-3">
          <div className="hidden sm:block text-right">
            <p className="text-sm font-medium text-pressing-text">
              {utilisateur.prenom} {utilisateur.nom}
            </p>
            <p className="text-xs text-gray-500">
              {ROLES_LABELS[utilisateur.role]}
            </p>
          </div>
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-gradient-to-br from-pressing-primary to-pressing-accent2 text-white text-sm">
              {utilisateur.prenom[0]}{utilisateur.nom[0]}
            </AvatarFallback>
          </Avatar>
          <Button
            variant="ghost"
            size="sm"
            onClick={onDeconnexion}
            className="text-gray-500 hover:text-red-500"
            title="Déconnexion"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}