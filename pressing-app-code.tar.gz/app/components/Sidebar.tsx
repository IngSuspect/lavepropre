'use client';

import React from 'react';
import { Home, Users, FileText, Settings, Menu, X, UserCog, LogOut, Shield, Package } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Avatar, AvatarFallback } from '../../components/ui/avatar';
import { Utilisateur, ROLES_LABELS } from '../types/pressing';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  utilisateur: Utilisateur;
  onDeconnexion: () => void;
}

const getMenuItems = (role: string) => {
  const baseItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: Home },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'articles', label: 'Articles', icon: Package },
    { id: 'factures', label: 'Facturation', icon: FileText },
  ];

  // Seuls les admins peuvent voir la gestion des utilisateurs
  if (role === 'admin') {
    baseItems.push({ id: 'utilisateurs', label: 'Utilisateurs', icon: UserCog });
  }

  baseItems.push({ id: 'settings', label: 'Paramètres', icon: Settings });
  
  return baseItems;
};

export default function Sidebar({ currentView, onViewChange, isOpen, onToggle, utilisateur, onDeconnexion }: SidebarProps) {
  console.log('Sidebar rendered - currentView:', currentView, 'isOpen:', isOpen, 'utilisateur:', utilisateur.prenom);
  
  const menuItems = getMenuItems(utilisateur.role);
  
  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 glass-effect border-r border-white/20 
        transform transition-transform duration-200 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/20">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-pressing-primary to-pressing-accent2 rounded-xl">
              <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">L</span>
              </div>
            </div>
            <div>
              <div className="text-lg font-semibold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
                LAVE PROPRE
              </div>
              <div className="text-sm text-gray-500">PRESSING</div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="lg:hidden"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="mt-6 px-3">
          <ul className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      console.log('Menu item clicked:', item.id);
                      onViewChange(item.id);
                      if (window.innerWidth < 1024) {
                        onToggle();
                      }
                    }}
                    className={`
                      w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left
                      transition-all duration-200 font-medium
                      ${isActive 
                        ? 'gradient-button text-white shadow-lg transform scale-[1.02]' 
                        : 'text-gray-600 hover:bg-pressing-secondary hover:text-pressing-primary hover:scale-[1.01]'
                      }
                    `}
                  >
                    <div className={`p-1 rounded-lg ${isActive ? 'bg-white/20' : 'bg-transparent'}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/20">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-gradient-to-br from-pressing-primary to-pressing-accent2 text-white text-sm">
                  {utilisateur.prenom[0]}{utilisateur.nom[0]}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-pressing-text truncate">
                  {utilisateur.prenom} {utilisateur.nom}
                </p>
                <div className="flex items-center gap-1">
                  <Badge 
                    className={`text-xs ${
                      utilisateur.role === 'admin' 
                        ? 'bg-red-100 text-red-800 border-red-200' 
                        : utilisateur.role === 'gestionnaire'
                        ? 'bg-blue-100 text-blue-800 border-blue-200'
                        : 'bg-green-100 text-green-800 border-green-200'
                    }`}
                    variant="outline"
                  >
                    {ROLES_LABELS[utilisateur.role]}
                  </Badge>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDeconnexion}
              className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
              title="Déconnexion"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
          <div className="text-xs text-gray-500 text-center">
            LAVE PROPRE PRESSING v1.0
          </div>
        </div>
      </div>
    </>
  );
}