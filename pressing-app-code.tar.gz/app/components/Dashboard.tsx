'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import DatabaseInit from './DatabaseInit';
import { 
  Users, 
  Euro, 
  TrendingUp, 
  CheckCircle,
  AlertCircle,
  Package,
  FileText
} from 'lucide-react';

interface DashboardProps {
  onViewChange?: (view: string) => void;
}

export default function Dashboard({ onViewChange }: DashboardProps) {
  console.log('Dashboard rendered');
  
  const handleQuickAction = (action: string) => {
    console.log('Quick action clicked:', action);
    if (onViewChange) {
      switch (action) {
        case 'ajouter-client':
          onViewChange('clients');
          break;
        case 'voir-factures':
          onViewChange('factures');
          break;
        case 'gerer-articles':
          onViewChange('articles');
          break;
        default:
          break;
      }
    }
  };

  return (
    <div className="p-6 space-y-6 relative">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `url(https://assets.macaly-user-data.dev/n4ro9vxsl732v9mkl7qm40y1/gnngftgmaatp7heqmyoz1di3/9Q5jZNWmD-OhZwnWY3D-W/tmpe-jiwgg-.webp)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      
      {/* Hero Section */}
      <div className="relative glass-effect rounded-2xl p-8 mb-8">
        <div className="flex flex-col lg:flex-row items-center gap-8">
          <div className="flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent mb-4">
              Tableau de Bord
            </h1>
            <p className="text-gray-600 text-lg">
              Gérez votre pressing avec style et efficacité
            </p>
          </div>
          <div className="lg:w-80">
            <img 
              src="https://assets.macaly-user-data.dev/n4ro9vxsl732v9mkl7qm40y1/gnngftgmaatp7heqmyoz1di3/C_u_0C5OEkW7mh7QlaEqf/tmpkwjroxnh.webp"
              alt="Services de pressing"
              className="w-full h-48 object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="card-hover bg-gradient-to-br from-pressing-primary via-pressing-lavender to-pressing-accent text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">Clients enregistrés</p>
                <p className="text-2xl font-bold">127</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <Users className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-mint to-pressing-accent text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">Articles disponibles</p>
                <p className="text-2xl font-bold">45</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <Package className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-accent2 to-purple-500 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">Factures émises</p>
                <p className="text-2xl font-bold">89</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <FileText className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="card-hover glass-effect border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="p-2 bg-pressing-primary/10 rounded-lg">
                <CheckCircle className="h-5 w-5 text-pressing-primary" />
              </div>
              État du système
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-pressing-secondary rounded-xl border border-green-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="font-medium text-pressing-text">Base de données</span>
                </div>
                <span className="text-green-600 font-semibold">Connectée</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-white rounded-xl border border-blue-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="font-medium text-pressing-text">API Services</span>
                </div>
                <span className="text-blue-600 font-semibold">Actifs</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-white rounded-xl border border-purple-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                  <span className="font-medium text-pressing-text">Application</span>
                </div>
                <span className="text-purple-600 font-semibold">En ligne</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover glass-effect border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="p-2 bg-pressing-accent/10 rounded-lg">
                <TrendingUp className="h-5 w-5 text-pressing-accent" />
              </div>
              Actions rapides
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3">
              <Button 
                onClick={() => handleQuickAction('ajouter-client')}
                className="gradient-button justify-start h-12 text-white border-0 shadow-lg hover:scale-105 transition-all"
              >
                <Users className="h-5 w-5 mr-2" />
                Ajouter un client
              </Button>
              <Button 
                onClick={() => handleQuickAction('gerer-articles')}
                variant="outline" 
                className="justify-start h-12 border-pressing-mint text-pressing-mint hover:bg-pressing-mint/10 hover:scale-105 transition-all"
              >
                <Package className="h-5 w-5 mr-2" />
                Gérer les articles
              </Button>
              <Button 
                onClick={() => handleQuickAction('voir-factures')}
                variant="outline" 
                className="justify-start h-12 border-pressing-accent2 text-pressing-accent2 hover:bg-pressing-accent2/10 hover:scale-105 transition-all"
              >
                <FileText className="h-5 w-5 mr-2" />
                Créer une facture
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <Card className="card-hover glass-effect border-0">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="p-2 bg-pressing-mint/10 rounded-lg">
              <img 
                src="https://assets.macaly-user-data.dev/n4ro9vxsl732v9mkl7qm40y1/gnngftgmaatp7heqmyoz1di3/OzKA41MMNaGvBjlJrBL9z/tmpcuvi8rbu.webp"
                alt="Services icon"
                className="h-6 w-6 object-contain"
              />
            </div>
            Vue d'ensemble hebdomadaire
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-6 bg-gradient-to-br from-pressing-primary/10 to-pressing-lavender/10 rounded-xl border border-pressing-primary/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-lavender bg-clip-text text-transparent">98%</p>
              <p className="text-sm text-gray-600 mt-2">Uptime système</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-pressing-mint/10 to-pressing-accent/10 rounded-xl border border-pressing-mint/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-mint to-pressing-accent bg-clip-text text-transparent">95%</p>
              <p className="text-sm text-gray-600 mt-2">Satisfaction client</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-pressing-accent2/10 to-orange-200 rounded-xl border border-pressing-accent2/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-accent2 to-orange-500 bg-clip-text text-transparent">24h</p>
              <p className="text-sm text-gray-600 mt-2">Service rapide</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-purple-100 to-pressing-primary/10 rounded-xl border border-purple-200">
              <p className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pressing-primary bg-clip-text text-transparent">12.5k</p>
              <p className="text-sm text-gray-600 mt-2">Prix moyen GNF</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}