'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Alert, AlertDescription } from '../../components/ui/alert';
import { connexionUtilisateur } from '../lib/mock-data';
import { Eye, EyeOff, Lock, Mail, Shirt } from 'lucide-react';

interface ConnexionProps {
  onConnexion: (utilisateur: any) => void;
}

export default function Connexion({ onConnexion }: ConnexionProps) {
  const [email, setEmail] = useState('');
  const [motDePasse, setMotDePasse] = useState('');
  const [afficherMotDePasse, setAfficherMotDePasse] = useState(false);
  const [erreur, setErreur] = useState('');
  const [chargement, setChargement] = useState(false);

  console.log('Connexion component rendered');

  const gererConnexion = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Tentative de connexion avec:', email);
    
    setErreur('');
    setChargement(true);

    try {
      const session = connexionUtilisateur(email, motDePasse);
      
      if (session) {
        console.log('Connexion réussie, redirection...');
        onConnexion(session);
      } else {
        setErreur('Email ou mot de passe incorrect');
      }
    } catch (error) {
      setErreur('Erreur lors de la connexion');
      console.error('Erreur connexion:', error);
    } finally {
      setChargement(false);
    }
  };

  const exempleConnexions = [
    { email: 'admin@lavepropre.com', motDePasse: 'admin123', role: 'Administrateur' },
    { email: 'aminata@lavepropre.com', motDePasse: 'employe123', role: 'Gestionnaire' },
    { email: 'ibrahima@lavepropre.com', motDePasse: 'employe456', role: 'Employé' }
  ];

  const utiliserExemple = (exemple: any) => {
    setEmail(exemple.email);
    setMotDePasse(exemple.motDePasse);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pressing-primary via-pressing-lavender to-pressing-accent flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url(https://assets.macaly-user-data.dev/n4ro9vxsl732v9mkl7qm40y1/gnngftgmaatp7heqmyoz1di3/9Q5jZNWmD-OhZwnWY3D-W/tmpe-jiwgg-.webp)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      
      <div className="w-full max-w-md relative z-10">
        {/* Logo et titre */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 rounded-full mb-4 backdrop-blur-sm">
            <Shirt className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">LAVE PROPRE</h1>
          <p className="text-white/80 text-lg">PRESSING</p>
        </div>

        {/* Formulaire de connexion */}
        <Card className="glass-effect border-0 shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
              Connexion
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {erreur && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {erreur}
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={gererConnexion} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2 text-pressing-text">
                  <Mail className="h-4 w-4" />
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre@email.com"
                  className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="motDePasse" className="flex items-center gap-2 text-pressing-text">
                  <Lock className="h-4 w-4" />
                  Mot de passe
                </Label>
                <div className="relative">
                  <Input
                    id="motDePasse"
                    type={afficherMotDePasse ? 'text' : 'password'}
                    value={motDePasse}
                    onChange={(e) => setMotDePasse(e.target.value)}
                    placeholder="••••••••"
                    className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl pr-12"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                    onClick={() => setAfficherMotDePasse(!afficherMotDePasse)}
                  >
                    {afficherMotDePasse ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full gradient-button text-white border-0 shadow-lg h-12"
                disabled={chargement}
              >
                {chargement ? 'Connexion...' : 'Se connecter'}
              </Button>
            </form>

            {/* Comptes de démonstration */}
            <div className="mt-6 pt-6 border-t border-pressing-primary/20">
              <p className="text-sm text-gray-600 mb-3 text-center">
                Comptes de démonstration :
              </p>
              <div className="space-y-2">
                {exempleConnexions.map((exemple, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full justify-between text-xs border-pressing-primary/20 hover:bg-pressing-secondary"
                    onClick={() => utiliserExemple(exemple)}
                  >
                    <span>{exemple.role}</span>
                    <span className="text-pressing-primary font-medium">{exemple.email}</span>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-white/60 text-sm mt-6">
          © 2024 LAVE PROPRE PRESSING - Système de gestion
        </p>
      </div>
    </div>
  );
}