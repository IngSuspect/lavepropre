'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Switch } from '../../components/ui/switch';
import { 
  Settings as SettingsIcon, 
  Store, 
  Bell, 
  Printer, 
  Euro,
  Save,
  User,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';

export default function Settings() {
  console.log('Settings rendered');
  
  const [activeTab, setActiveTab] = useState('entreprise');
  
  const tabs = [
    { id: 'entreprise', label: 'Entreprise', icon: Store },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'impression', label: 'Impression', icon: Printer },
    { id: 'tarifs', label: 'Tarifs', icon: Euro },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-pressing-text">Paramètres</h2>
        <p className="text-gray-600 mt-1">Configurez votre système de gestion</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Tabs */}
        <Card className="lg:col-span-1">
          <CardContent className="p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors
                      ${activeTab === tab.id 
                        ? 'bg-pressing-secondary text-pressing-primary border border-pressing-primary/20' 
                        : 'text-gray-600 hover:bg-gray-50 hover:text-pressing-text'
                      }
                    `}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </CardContent>
        </Card>

        {/* Content */}
        <div className="lg:col-span-3">
          {activeTab === 'entreprise' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="h-5 w-5" />
                  Informations de l'entreprise
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nom-entreprise">Nom de l'entreprise</Label>
                    <Input
                      id="nom-entreprise"
                      placeholder="LAVE PROPRE PRESSING"
                      defaultValue="LAVE PROPRE PRESSING"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="siret">SIRET</Label>
                    <Input
                      id="siret"
                      placeholder="12345678901234"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="adresse">Adresse complète</Label>
                  <Textarea
                    id="adresse"
                    placeholder="123 Rue de la Propreté, 75001 Paris"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="telephone">Téléphone</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="telephone"
                        placeholder="01 23 45 67 89"
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="contact@laveproprepressing.fr"
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tva">Numéro de TVA</Label>
                    <Input
                      id="tva"
                      placeholder="FR12345678901"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="taux-tva">Taux de TVA (%)</Label>
                    <Input
                      id="taux-tva"
                      type="number"
                      placeholder="20"
                      defaultValue="20"
                    />
                  </div>
                </div>

                <Button className="bg-pressing-primary hover:bg-pressing-primary/90">
                  <Save className="h-4 w-4 mr-2" />
                  Sauvegarder
                </Button>
              </CardContent>
            </Card>
          )}

          {activeTab === 'notifications' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Notifications
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notif-commandes">Nouvelles commandes</Label>
                      <p className="text-sm text-gray-600">Recevoir une notification pour chaque nouvelle commande</p>
                    </div>
                    <Switch id="notif-commandes" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notif-pret">Commandes prêtes</Label>
                      <p className="text-sm text-gray-600">Notification quand une commande est prête</p>
                    </div>
                    <Switch id="notif-pret" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notif-retard">Commandes en retard</Label>
                      <p className="text-sm text-gray-600">Alerte pour les commandes dépassant la date prévue</p>
                    </div>
                    <Switch id="notif-retard" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notif-paiement">Paiements reçus</Label>
                      <p className="text-sm text-gray-600">Notification lors de la réception d'un paiement</p>
                    </div>
                    <Switch id="notif-paiement" />
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-medium text-pressing-text">Email</h3>
                  <div className="space-y-2">
                    <Label htmlFor="email-notif">Adresse email pour les notifications</Label>
                    <Input
                      id="email-notif"
                      type="email"
                      placeholder="admin@laveproprepressing.fr"
                    />
                  </div>
                </div>

                <Button className="bg-pressing-primary hover:bg-pressing-primary/90">
                  <Save className="h-4 w-4 mr-2" />
                  Sauvegarder
                </Button>
              </CardContent>
            </Card>
          )}

          {activeTab === 'impression' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Printer className="h-5 w-5" />
                  Paramètres d'impression
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="format-ticket">Format des tickets</Label>
                    <select
                      id="format-ticket"
                      className="w-full px-3 py-2 border border-gray-200 rounded-md bg-white text-sm focus:outline-none focus:ring-2 focus:ring-pressing-primary"
                    >
                      <option value="80mm">80mm (standard)</option>
                      <option value="58mm">58mm (petit)</option>
                      <option value="a4">A4</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-print">Impression automatique</Label>
                      <p className="text-sm text-gray-600">Imprimer automatiquement les tickets de dépôt</p>
                    </div>
                    <Switch id="auto-print" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="print-barcode">Code-barres</Label>
                      <p className="text-sm text-gray-600">Inclure un code-barres sur les tickets</p>
                    </div>
                    <Switch id="print-barcode" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="footer-ticket">Pied de page des tickets</Label>
                  <Textarea
                    id="footer-ticket"
                    placeholder="Merci de votre confiance - LAVE PROPRE PRESSING"
                    rows={3}
                  />
                </div>

                <Button className="bg-pressing-primary hover:bg-pressing-primary/90">
                  <Save className="h-4 w-4 mr-2" />
                  Sauvegarder
                </Button>
              </CardContent>
            </Card>
          )}

          {activeTab === 'tarifs' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Euro className="h-5 w-5" />
                  Gestion des tarifs
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  {[
                    { nom: 'Nettoyage à sec', prix: 8.50 },
                    { nom: 'Repassage', prix: 3.50 },
                    { nom: 'Lavage + Repassage', prix: 6.00 },
                    { nom: 'Teinture', prix: 15.00 },
                    { nom: 'Retouche', prix: 12.00 },
                  ].map((service, index) => (
                    <div key={index} className="flex items-center gap-4 p-3 bg-pressing-background rounded-lg">
                      <div className="flex-1">
                        <Input
                          placeholder="Nom du service"
                          defaultValue={service.nom}
                        />
                      </div>
                      <div className="w-24">
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Prix"
                          defaultValue={service.prix}
                        />
                      </div>
                      <span className="text-gray-500">€</span>
                    </div>
                  ))}
                </div>

                <Button variant="outline" className="w-full">
                  <Euro className="h-4 w-4 mr-2" />
                  Ajouter un service
                </Button>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <Label htmlFor="remise-fidelite">Remise fidélité (%)</Label>
                      <p className="text-sm text-gray-600">Remise accordée aux clients fidèles</p>
                    </div>
                    <div className="w-20">
                      <Input
                        id="remise-fidelite"
                        type="number"
                        placeholder="5"
                        defaultValue="5"
                      />
                    </div>
                  </div>
                </div>

                <Button className="bg-pressing-primary hover:bg-pressing-primary/90">
                  <Save className="h-4 w-4 mr-2" />
                  Sauvegarder les tarifs
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}