'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../../components/ui/dialog';
import { Client } from '../types/pressing';
import { mockCommandes, mockFactures } from '../lib/mock-data';
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  FileText, 
  ShoppingBag, 
  TrendingUp,
  Eye,
  CreditCard
} from 'lucide-react';

interface ClientDetailsProps {
  client: Client;
  trigger: React.ReactNode;
}

export default function ClientDetails({ client, trigger }: ClientDetailsProps) {
  console.log('ClientDetails rendered for:', client.codeClient);

  // Récupérer les commandes et factures du client
  const commandesClient = mockCommandes.filter(cmd => cmd.clientId === client.id);
  const facturesClient = mockFactures.filter(fac => fac.commande.clientId === client.id);

  // Calculer les statistiques
  const stats = {
    totalCommandes: commandesClient.length,
    totalFactures: facturesClient.length,
    montantTotal: facturesClient.reduce((sum, fac) => sum + fac.montantTTC, 0),
    montantPaye: facturesClient.filter(fac => fac.statut === 'payee').reduce((sum, fac) => sum + fac.montantTTC, 0),
    montantEnAttente: facturesClient.filter(fac => fac.statut === 'en_attente').reduce((sum, fac) => sum + fac.montantTTC, 0),
    derniereCommande: commandesClient.length > 0 ? commandesClient.sort((a, b) => 
      new Date(b.dateDepot).getTime() - new Date(a.dateDepot).getTime()
    )[0] : null
  };

  const statutCommandeCouleurs = {
    en_attente: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    en_cours: 'bg-blue-100 text-blue-800 border-blue-200',
    pret: 'bg-green-100 text-green-800 border-green-200',
    retire: 'bg-gray-100 text-gray-800 border-gray-200',
    annule: 'bg-red-100 text-red-800 border-red-200',
  };

  const statutFactureCouleurs = {
    en_attente: 'bg-orange-100 text-orange-800 border-orange-200',
    payee: 'bg-green-100 text-green-800 border-green-200',
    en_retard: 'bg-red-100 text-red-800 border-red-200',
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-pressing-primary to-pressing-accent rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold">{client.prenom} {client.nom}</span>
              <p className="text-sm text-gray-500 font-normal">Code client: {client.codeClient}</p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informations personnelles */}
          <Card className="glass-effect border-0">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5" />
                Informations personnelles
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-pressing-secondary rounded-lg">
                    <Phone className="h-4 w-4 text-pressing-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Téléphone</p>
                    <p className="font-medium">{client.telephone}</p>
                  </div>
                </div>

                {client.email && (
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-pressing-secondary rounded-lg">
                      <Mail className="h-4 w-4 text-pressing-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-medium">{client.email}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3 md:col-span-2">
                  <div className="p-2 bg-pressing-secondary rounded-lg">
                    <MapPin className="h-4 w-4 text-pressing-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Adresse</p>
                    <p className="font-medium">{client.adresse}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="p-2 bg-pressing-secondary rounded-lg">
                    <Calendar className="h-4 w-4 text-pressing-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Client depuis</p>
                    <p className="font-medium">{client.dateCreation.toLocaleDateString('fr-FR')}</p>
                  </div>
                </div>
              </div>

              {client.notes && (
                <div className="mt-4 p-3 bg-pressing-background rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Notes</p>
                  <p className="text-sm">{client.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Statistiques */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="card-hover bg-gradient-to-br from-pressing-primary to-pressing-accent text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/80 text-sm">Commandes</p>
                    <p className="text-2xl font-bold">{stats.totalCommandes}</p>
                  </div>
                  <ShoppingBag className="h-8 w-8 text-white/80" />
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover bg-gradient-to-br from-pressing-mint to-pressing-accent text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/80 text-sm">Factures</p>
                    <p className="text-2xl font-bold">{stats.totalFactures}</p>
                  </div>
                  <FileText className="h-8 w-8 text-white/80" />
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover bg-gradient-to-br from-purple-500 to-pressing-accent2 text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/80 text-sm">CA Total</p>
                    <p className="text-lg font-bold">{stats.montantTotal.toLocaleString()} GNF</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-white/80" />
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover bg-gradient-to-br from-orange-500 to-pressing-accent2 text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/80 text-sm">En attente</p>
                    <p className="text-lg font-bold">{stats.montantEnAttente.toLocaleString()} GNF</p>
                  </div>
                  <CreditCard className="h-8 w-8 text-white/80" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Historique résumé */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="glass-effect border-0">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5" />
                  Dernières commandes
                </CardTitle>
              </CardHeader>
              <CardContent>
                {commandesClient.length > 0 ? (
                  <div className="space-y-2">
                    {commandesClient.slice(0, 3).map((commande) => (
                      <div key={commande.id} className="flex items-center justify-between p-2 bg-pressing-background rounded">
                        <div>
                          <p className="font-medium text-sm">{commande.numeroCommande}</p>
                          <p className="text-xs text-gray-600">{commande.dateDepot.toLocaleDateString('fr-FR')}</p>
                        </div>
                        <p className="text-sm font-semibold text-pressing-primary">
                          {commande.total.toLocaleString()} GNF
                        </p>
                      </div>
                    ))}
                    {commandesClient.length > 3 && (
                      <p className="text-xs text-gray-500 text-center mt-2">
                        +{commandesClient.length - 3} autres commandes
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-4">Aucune commande</p>
                )}
              </CardContent>
            </Card>

            <Card className="glass-effect border-0">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Dernières factures
                </CardTitle>
              </CardHeader>
              <CardContent>
                {facturesClient.length > 0 ? (
                  <div className="space-y-2">
                    {facturesClient.slice(0, 3).map((facture) => (
                      <div key={facture.id} className="flex items-center justify-between p-2 bg-pressing-background rounded">
                        <div>
                          <p className="font-medium text-sm">{facture.numeroFacture}</p>
                          <p className="text-xs text-gray-600">{facture.dateFacture.toLocaleDateString('fr-FR')}</p>
                        </div>
                        <p className="text-sm font-semibold text-pressing-primary">
                          {facture.montantTTC.toLocaleString()} GNF
                        </p>
                      </div>
                    ))}
                    {facturesClient.length > 3 && (
                      <p className="text-xs text-gray-500 text-center mt-2">
                        +{facturesClient.length - 3} autres factures
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-4">Aucune facture</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Résumé financier */}
          <Card className="glass-effect border-0">
            <CardHeader>
              <CardTitle className="text-lg">Résumé financier</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-2xl font-bold text-green-600">
                    {stats.montantPaye.toLocaleString()} GNF
                  </p>
                  <p className="text-sm text-gray-600 mt-1">Montant payé</p>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg border border-orange-200">
                  <p className="text-2xl font-bold text-orange-600">
                    {stats.montantEnAttente.toLocaleString()} GNF
                  </p>
                  <p className="text-sm text-gray-600 mt-1">En attente</p>
                </div>
                <div className="text-center p-4 bg-pressing-secondary rounded-lg border border-pressing-primary/20">
                  <p className="text-2xl font-bold text-pressing-primary">
                    {stats.montantTotal.toLocaleString()} GNF
                  </p>
                  <p className="text-sm text-gray-600 mt-1">Chiffre d'affaires total</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}