'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { mockCommandes } from '../lib/mock-data';
import { STATUT_COULEURS, STATUT_LABELS } from '../types/pressing';
import { Search, Filter, Plus, Eye, Edit, Calendar, Package, Shirt, Tags, Archive, Grid3X3 } from 'lucide-react';

export default function CommandesList() {
  console.log('CommandesList rendered');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const filteredCommandes = mockCommandes.filter(commande => {
    const matchesSearch = 
      commande.numeroCommande.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `${commande.client.prenom} ${commande.client.nom}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      commande.client.telephone.includes(searchTerm);
    
    const matchesStatus = selectedStatus === 'all' || commande.statut === selectedStatus;
    
    return matchesSearch && matchesStatus;
  });

  const statusOptions = [
    { value: 'all', label: 'Tous les statuts' },
    { value: 'en_attente', label: 'En attente' },
    { value: 'en_cours', label: 'En cours' },
    { value: 'pret', label: 'Prêt' },
    { value: 'retire', label: 'Retiré' },
    { value: 'annule', label: 'Annulé' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
            Commandes
          </h2>
          <p className="text-gray-600 mt-2 text-lg">Gérez toutes vos commandes avec style</p>
        </div>
        <Button className="gradient-button w-full sm:w-auto text-white border-0 shadow-lg">
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle commande
        </Button>
      </div>

      {/* Filters */}
      <Card className="glass-effect border-0 card-hover">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 p-1 bg-pressing-primary/10 rounded-lg">
                <Search className="h-4 w-4 text-pressing-primary" />
              </div>
              <Input
                type="text"
                placeholder="Rechercher par numéro, nom, téléphone..."
                className="pl-12 border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-pressing-primary/20 rounded-xl bg-white/70 text-sm focus:outline-none focus:ring-2 focus:ring-pressing-primary backdrop-blur-sm"
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <Button variant="outline" size="sm" className="border-pressing-accent text-pressing-accent hover:bg-pressing-accent/10 rounded-xl">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="grid gap-6">
        {filteredCommandes.map((commande) => (
          <Card key={commande.id} className="card-hover glass-effect border-0">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row gap-4">
                {/* Main Info */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-pressing-text">
                      {commande.numeroCommande}
                    </h3>
                    <Badge className={STATUT_COULEURS[commande.statut]} variant="outline">
                      {STATUT_LABELS[commande.statut]}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                    <div>
                      <p className="font-medium text-pressing-text">
                        {commande.client.prenom} {commande.client.nom}
                      </p>
                      <p>{commande.client.telephone}</p>
                      {commande.client.email && <p>{commande.client.email}</p>}
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-1 mb-1">
                        <Calendar className="h-4 w-4" />
                        <span>
                          Dépôt: {new Date(commande.dateDepot).toLocaleDateString('fr-FR')}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>
                          Retrait prévu: {new Date(commande.datePrevueRetrait).toLocaleDateString('fr-FR')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Articles détaillés */}
                  <div className="mt-4 space-y-2">
                    <p className="text-sm font-medium text-gray-700 flex items-center gap-1">
                      <Package className="h-4 w-4" />
                      Articles traités:
                    </p>
                    <div className="space-y-2">
                      {commande.articles.map((articleCommande) => {
                        const getCategoryIcon = (categorie: string) => {
                          switch (categorie) {
                            case 'vetements': return Shirt;
                            case 'accessoires': return Tags;
                            case 'chaussures': return Package;
                            case 'cuir': return Archive;
                            case 'linge': return Grid3X3;
                            default: return Package;
                          }
                        };
                        
                        const CategoryIcon = getCategoryIcon(articleCommande.article.categorie);
                        
                        return (
                          <div key={articleCommande.id} className="flex items-center gap-2 p-2 bg-white/50 rounded-lg">
                            <div className="w-6 h-6 bg-pressing-primary/10 rounded flex items-center justify-center">
                              <CategoryIcon className="h-3 w-3 text-pressing-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-pressing-text truncate">
                                  {articleCommande.article.designation}
                                </span>
                                <span className="text-xs font-mono bg-pressing-secondary text-pressing-primary px-1.5 py-0.5 rounded">
                                  {articleCommande.article.codeArticle}
                                </span>
                              </div>
                              <div className="text-xs text-gray-600">
                                {articleCommande.service.nom} • Qté: {articleCommande.quantite}
                                {articleCommande.article.couleur && ` • ${articleCommande.article.couleur}`}
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-bold text-pressing-primary">
                                {articleCommande.sousTotal.toLocaleString()} GNF
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Price & Actions */}
                <div className="lg:min-w-[200px] flex flex-col justify-between">
                  <div className="text-right mb-4">
                    <p className="text-2xl font-bold text-pressing-text">
                      {commande.total.toLocaleString()} GNF
                    </p>
                    {commande.resteDu > 0 && (
                      <p className="text-sm text-orange-600">
                        Reste dû: {commande.resteDu.toLocaleString()} GNF
                      </p>
                    )}
                    {commande.modePaiement && (
                      <p className="text-xs text-gray-500 capitalize">
                        {commande.modePaiement}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1 border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white rounded-xl transition-all">
                      <Eye className="h-4 w-4 mr-1" />
                      Voir
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 border-pressing-accent2 text-pressing-accent2 hover:bg-pressing-accent2 hover:text-white rounded-xl transition-all">
                      <Edit className="h-4 w-4 mr-1" />
                      Modifier
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCommandes.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Search className="h-12 w-12 mx-auto mb-4" />
              <p className="text-lg font-medium">Aucune commande trouvée</p>
              <p className="text-sm">Essayez de modifier vos critères de recherche</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}