'use client';

import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../../components/ui/dialog';
import { useToast } from '../../hooks/use-toast';

// Lazy loading pour ClientDetails
const ClientDetails = lazy(() => import('./ClientDetails'));
import { 
  Search, 
  FileText, 
  Download, 
  Send, 
  Euro, 
  Calendar,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Eye,
  User,
  MapPin,
  Package,
  Shirt,
  Tags,
  Archive,
  Grid3X3,
  Printer,
  Plus,
  Save,
  X,
  ShoppingCart
} from 'lucide-react';

export default function Facturation() {
  console.log('Facturation rendered');
  
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [factures, setFactures] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [articles, setArticles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<string>('');
  const [selectedArticles, setSelectedArticles] = useState<any[]>([]);
  const [newFacture, setNewFacture] = useState({
    numeroFacture: '',
    dateFacture: new Date().toISOString().split('T')[0],
    dateEcheance: '',
    modePaiement: 'especes',
    notesFacture: ''
  });

  // Charger les données depuis les APIs
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      console.log('Loading facturation data...');
      setLoading(true);
      
      // Charger factures, clients et articles en parallèle
      const [facturesRes, clientsRes, articlesRes] = await Promise.all([
        fetch('/api/factures'),
        fetch('/api/clients'),
        fetch('/api/articles')
      ]);
      
      if (!facturesRes.ok || !clientsRes.ok || !articlesRes.ok) {
        throw new Error('Erreur lors du chargement des données');
      }
      
      const [facturesData, clientsData, articlesData] = await Promise.all([
        facturesRes.json(),
        clientsRes.json(), 
        articlesRes.json()
      ]);
      
      console.log('Facturation data loaded:', { 
        factures: facturesData, 
        clients: clientsData, 
        articles: articlesData 
      });
      
      setFactures(facturesData);
      setClients(clientsData);
      setArticles(articlesData);
      
      // Générer le prochain numéro de facture
      const nextNumber = String(facturesData.length + 1).padStart(3, '0');
      setNewFacture(prev => ({
        ...prev,
        numeroFacture: `FAC${nextNumber}`
      }));
      
    } catch (error) {
      console.error('Erreur lors du chargement des données:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les données de facturation",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };



  // Ajouter un article à la facture
  const addArticleToFacture = (article: any) => {
    console.log('Adding article to facture:', article);
    
    if (selectedArticles.find(a => a.id === article.id)) {
      // Si l'article existe déjà, augmenter la quantité
      setSelectedArticles(prev => 
        prev.map(a => 
          a.id === article.id 
            ? { ...a, quantite: a.quantite + 1, sousTotal: (a.quantite + 1) * a.prix }
            : a
        )
      );
    } else {
      // Ajouter un nouvel article
      setSelectedArticles(prev => [
        ...prev,
        {
          ...article,
          quantite: 1,
          sousTotal: article.prix
        }
      ]);
    }
  };

  // Retirer un article de la facture
  const removeArticleFromFacture = (articleId: string) => {
    setSelectedArticles(prev => prev.filter(a => a.id !== articleId));
  };

  // Modifier la quantité d'un article
  const updateArticleQuantity = (articleId: string, quantite: number) => {
    if (quantite <= 0) {
      removeArticleFromFacture(articleId);
      return;
    }
    
    setSelectedArticles(prev => 
      prev.map(a => 
        a.id === articleId 
          ? { ...a, quantite, sousTotal: quantite * a.prix }
          : a
      )
    );
  };

  // Créer une nouvelle facture
  const handleCreateFacture = async () => {
    console.log('Creating new facture:', { newFacture, selectedClient, selectedArticles });
    
    if (!selectedClient || selectedArticles.length === 0) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un client et au moins un article",
        variant: "destructive"
      });
      return;
    }

    try {
      const montantHT = selectedArticles.reduce((sum, a) => sum + a.sousTotal, 0);
      const tva = montantHT * 0.20; // TVA 20%
      const montantTTC = montantHT + tva;
      
      const factureData = {
        numero_facture: newFacture.numeroFacture,
        client_id: selectedClient,
        date_facture: newFacture.dateFacture,
        montant_total: montantTTC,
        statut_paiement: 'non_paye'
      };

      const response = await fetch('/api/factures', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(factureData),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la création de la facture');
      }

      const createdFacture = await response.json();
      console.log('Facture created successfully:', createdFacture);
      
      toast({
        title: "Succès",
        description: "Facture créée avec succès",
      });

      resetForm();
      await loadData(); // Recharger la liste
    } catch (error) {
      console.error('Erreur lors de la création de la facture:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer la facture",
        variant: "destructive"
      });
    }
  };

  // Réinitialiser le formulaire
  const resetForm = () => {
    setSelectedClient('');
    setSelectedArticles([]);
    setNewFacture({
      numeroFacture: `FAC${String(factures.length + 2).padStart(3, '0')}`,
      dateFacture: new Date().toISOString().split('T')[0],
      dateEcheance: '',
      modePaiement: 'especes',
      notesFacture: ''
    });
    setIsCreateModalOpen(false);
  };

  // Fonction d'impression
  const handlePrint = (facture: any) => {
    console.log('Impression de la facture:', facture.numero_facture);
    
    const printWindow = window.open('', '_blank');
    
    if (printWindow) {
      const montantHT = Math.round(facture.montant_total / 1.20);
      const tva = facture.montant_total - montantHT;
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Facture ${facture.numero_facture}</title>
            <style>
              @page { margin: 1cm; size: A4; }
              @media print { body { -webkit-print-color-adjust: exact; } }
              body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background: white; 
                color: #1a1a1a; 
                font-size: 13px;
                line-height: 1.5;
              }
              .header { 
                text-align: center; 
                border-bottom: 3px solid #6366F1; 
                padding-bottom: 25px; 
                margin-bottom: 35px; 
                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                padding: 25px;
                border-radius: 10px;
              }
              .pressing-name { 
                font-size: 28px; 
                font-weight: bold; 
                color: #6366F1; 
                margin-bottom: 10px; 
                text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
              }
              .company-subtitle {
                font-size: 16px;
                color: #64748b;
                margin-bottom: 15px;
              }
              .company-contact {
                font-size: 14px;
                color: #475569;
              }
              .invoice-title { 
                font-size: 24px; 
                font-weight: bold; 
                margin: 25px 0; 
                text-align: center;
                color: #6366F1;
                background: linear-gradient(135deg, #6366F1, #8b5cf6);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
              }
              .info-section { 
                margin-bottom: 25px; 
                padding: 20px; 
                background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); 
                border-left: 5px solid #6366F1; 
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
              }
              .info-section h3 { 
                margin: 0 0 15px 0; 
                color: #6366F1; 
                font-size: 16px;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 8px;
              }
              .info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 30px;
                margin-bottom: 25px;
              }
              .status-badge {
                display: inline-block;
                padding: 6px 16px;
                border-radius: 25px;
                font-size: 12px;
                font-weight: bold;
                ${facture.statut_paiement === 'paye' ? 'background: #22c55e; color: white;' : 
                  facture.statut_paiement === 'non_paye' ? 'background: #f59e0b; color: white;' : 
                  'background: #ef4444; color: white;'}
              }
              .amounts-section { 
                margin-top: 25px; 
                text-align: right; 
                border-top: 2px solid #6366F1; 
                padding-top: 15px; 
                background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
                padding: 20px;
                border-radius: 8px;
              }
              .amount-line { 
                margin: 8px 0; 
                padding: 6px 0; 
                display: flex;
                justify-content: space-between;
                align-items: center;
              }
              .amount-final { 
                font-size: 20px; 
                font-weight: bold; 
                color: #6366F1; 
                border-top: 2px solid #6366F1; 
                padding-top: 15px; 
                margin-top: 15px; 
                background: white;
                padding: 15px;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(99, 102, 241, 0.1);
              }
              .footer { 
                margin-top: 40px; 
                text-align: center; 
                font-size: 11px; 
                color: #64748b; 
                border-top: 1px solid #e2e8f0; 
                padding-top: 20px; 
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
              }
              .info-item {
                margin: 8px 0;
                display: flex;
                justify-content: space-between;
              }
              .info-label {
                font-weight: 600;
                color: #374151;
              }
              .info-value {
                color: #6b7280;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="pressing-name">🧽 PRESSING MODERNE</div>
              <div class="company-subtitle">Service de nettoyage et repassage professionnel</div>
              <div class="company-contact">
                📞 +224 XXX XXX XXX | 📧 contact@pressing.gn<br>
                📍 Conakry, République de Guinée
              </div>
            </div>

            <div class="invoice-title">🧾 FACTURE N° ${facture.numero_facture}</div>
            
            <div class="info-grid">
              <div class="info-section">
                <h3>👤 INFORMATIONS CLIENT</h3>
                <div class="info-item">
                  <span class="info-label">Nom complet:</span>
                  <span class="info-value">${facture.clients?.prenom || ''} ${facture.clients?.nom || ''}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">Code client:</span>
                  <span class="info-value">${facture.clients?.code_client || ''}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">Téléphone:</span>
                  <span class="info-value">${facture.clients?.telephone || ''}</span>
                </div>
                ${facture.clients?.email ? `
                  <div class="info-item">
                    <span class="info-label">Email:</span>
                    <span class="info-value">${facture.clients.email}</span>
                  </div>
                ` : ''}
              </div>
              
              <div class="info-section">
                <h3>📋 INFORMATIONS FACTURE</h3>
                <div class="info-item">
                  <span class="info-label">Date facture:</span>
                  <span class="info-value">${new Date(facture.date_facture).toLocaleDateString('fr-FR')}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">Date création:</span>
                  <span class="info-value">${new Date(facture.created_at).toLocaleDateString('fr-FR')} à ${new Date(facture.created_at).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">Statut:</span>
                  <span class="status-badge">${
                    facture.statut_paiement === 'paye' ? '✅ Payée' : 
                    facture.statut_paiement === 'non_paye' ? '⏳ Non payée' : '⚠️ En retard'
                  }</span>
                </div>
                <div class="info-item">
                  <span class="info-label">ID Facture:</span>
                  <span class="info-value">${facture.id?.slice(0, 8)}...</span>
                </div>
              </div>
            </div>

            <div class="amounts-section">
              <div class="amount-line">
                <span>💰 Sous-total HT:</span>
                <strong>${montantHT.toLocaleString()} GNF</strong>
              </div>
              <div class="amount-line">
                <span>🏛️ TVA (20%):</span>
                <strong>${tva.toLocaleString()} GNF</strong>
              </div>
              <div class="amount-final">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <span>🎯 TOTAL TTC:</span>
                  <strong>${facture.montant_total.toLocaleString()} GNF</strong>
                </div>
              </div>
            </div>

            <div class="footer">
              <div style="margin-bottom: 10px;">
                <strong>🙏 Merci de votre confiance !</strong>
              </div>
              <div>
                Cette facture a été générée automatiquement le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}
              </div>
              <div style="margin-top: 10px; font-style: italic;">
                Pressing Moderne - Votre partenaire de confiance pour l'entretien de vos vêtements
              </div>
            </div>
          </body>
        </html>
      `);
      
      printWindow.document.close();
      printWindow.focus();
      
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 500);
    }
  };

  // Marquer une facture comme payée
  const handlePaymentUpdate = async (factureId: string) => {
    console.log('Updating payment status for facture:', factureId);
    
    try {
      const response = await fetch('/api/factures', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: factureId,
          statut_paiement: 'paye'
        }),
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la mise à jour du statut');
      }

      toast({
        title: "Succès",
        description: "Facture marquée comme payée",
      });

      await loadData(); // Recharger la liste
    } catch (error) {
      console.error('Erreur lors de la mise à jour du statut:', error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le statut",
        variant: "destructive"
      });
    }
  };

  const filteredFactures = factures.filter(facture => {
    const matchesSearch = 
      facture.numero_facture?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      facture.client_id?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || facture.statut_paiement === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Calculs statistiques
  const stats = {
    totalFactures: factures.length,
    facturespayees: factures.filter(f => f.statut_paiement === 'paye').length,
    facturesEnAttente: factures.filter(f => f.statut_paiement === 'non_paye').length,
    chiffreAffaires: factures.reduce((sum, f) => sum + (f.montant_total || 0), 0),
    montantEnAttente: factures.filter(f => f.statut_paiement === 'non_paye').reduce((sum, f) => sum + (f.montant_total || 0), 0),
  };

  const statutCouleurs = {
    non_paye: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    paye: 'bg-green-100 text-green-800 border-green-200',
    en_retard: 'bg-red-100 text-red-800 border-red-200',
  };

  const statutLabels = {
    non_paye: 'Non payée',
    paye: 'Payée',
    en_retard: 'En retard',
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-mint bg-clip-text text-transparent">
            Facturation
          </h2>
          <p className="text-gray-600 mt-2 text-lg">Gérez vos factures et paiements en toute simplicité</p>
        </div>
        <Button 
          onClick={() => setIsCreateModalOpen(true)}
          className="gradient-button w-full sm:w-auto text-white border-0 shadow-lg"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle facture
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="card-hover bg-gradient-to-br from-pressing-primary via-pressing-lavender to-pressing-accent text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">Total factures</p>
                <p className="text-2xl font-bold">{stats.totalFactures}</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <FileText className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-mint to-pressing-accent text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">Factures payées</p>
                <p className="text-2xl font-bold">{stats.facturespayees}</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <CheckCircle className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-pressing-accent2 to-orange-400 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">En attente</p>
                <p className="text-2xl font-bold">{stats.facturesEnAttente}</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <AlertTriangle className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-gradient-to-br from-purple-500 via-pressing-primary to-pressing-accent2 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">CA total</p>
                <p className="text-2xl font-bold">{stats.chiffreAffaires.toLocaleString()} GNF</p>
              </div>
              <div className="p-3 bg-white/20 rounded-full">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Rechercher par facture, client, code client, commande..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-md bg-white text-sm focus:outline-none focus:ring-2 focus:ring-pressing-primary"
            >
              <option value="all">Tous les statuts</option>
              <option value="non_paye">Non payées</option>
              <option value="paye">Payées</option>
              <option value="en_retard">En retard</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Factures List */}
      {loading ? (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-pressing-primary">Chargement des factures...</div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredFactures.map((facture) => (
            <Card key={facture.id} className="card-hover glass-effect border-0">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Main Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-pressing-primary to-pressing-accent rounded-xl flex items-center justify-center">
                        <FileText className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-pressing-text">
                          {facture.numero_facture}
                        </h3>
                        <div className="flex items-center gap-2">
                          <Badge className={statutCouleurs[facture.statut_paiement]} variant="outline">
                            {statutLabels[facture.statut_paiement]}
                          </Badge>
                          <span className="text-sm text-gray-500">• ID: {facture.id?.slice(0, 8)}...</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Informations client */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-pressing-mint to-pressing-accent rounded-full flex items-center justify-center">
                            <User className="h-5 w-5 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold text-pressing-text">
                              {facture.clients?.prenom} {facture.clients?.nom}
                            </p>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-mono bg-pressing-secondary text-pressing-primary px-2 py-1 rounded">
                                {facture.clients?.code_client}
                              </span>
                              <span className="text-sm text-gray-600">{facture.clients?.telephone}</span>
                            </div>
                          </div>
                        </div>
                        
                        {facture.clients?.email && (
                          <div className="pl-13">
                            <p className="text-sm text-gray-600">
                              📧 {facture.clients.email}
                            </p>
                          </div>
                        )}
                      </div>
                      
                      {/* Informations facture */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="h-4 w-4" />
                          <span>Émise: {new Date(facture.date_facture).toLocaleDateString('fr-FR')}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="h-4 w-4" />
                          <span>Créée: {new Date(facture.created_at).toLocaleDateString('fr-FR')} à {new Date(facture.created_at).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Euro className="h-4 w-4" />
                          <span className="font-semibold">Montant: {facture.montant_total.toLocaleString()} GNF</span>
                        </div>
                      </div>
                    </div>

                    {/* Détail montants */}
                    <div className="mt-4 p-4 bg-gradient-to-r from-pressing-background to-pressing-secondary rounded-xl border border-pressing-primary/20">
                      <div className="space-y-2 mb-3">
                        <div className="flex justify-between text-sm">
                          <span>Sous-total HT:</span>
                          <span>{Math.round(facture.montant_total / 1.20).toLocaleString()} GNF</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>TVA (20%):</span>
                          <span>{Math.round(facture.montant_total - facture.montant_total / 1.20).toLocaleString()} GNF</span>
                        </div>
                        <hr className="border-pressing-primary/20" />
                      </div>
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total TTC</span>
                        <span className="text-pressing-primary">{facture.montant_total.toLocaleString()} GNF</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="lg:min-w-[200px] flex flex-col gap-3">
                    <Suspense fallback={
                      <Button variant="outline" size="sm" className="w-full border-pressing-mint text-pressing-mint opacity-50" disabled>
                        <Eye className="h-4 w-4 mr-2" />
                        Chargement...
                      </Button>
                    }>
                      <ClientDetails 
                        client={{
                          id: facture.client_id,
                          nom: facture.clients?.nom || '',
                          prenom: facture.clients?.prenom || '',
                          email: facture.clients?.email || '',
                          telephone: facture.clients?.telephone || '',
                          codeClient: facture.clients?.code_client || '',
                          adresse: '',
                          dateCreation: new Date()
                        }}
                        trigger={
                          <Button variant="outline" size="sm" className="w-full border-pressing-mint text-pressing-mint hover:bg-pressing-mint hover:text-white rounded-xl transition-all">
                            <Eye className="h-4 w-4 mr-2" />
                            Voir client
                          </Button>
                        }
                      />
                    </Suspense>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white rounded-xl transition-all"
                      onClick={() => handlePrint(facture)}
                    >
                      <Printer className="h-4 w-4 mr-2" />
                      Imprimer facture
                    </Button>
                    <Button variant="outline" size="sm" className="w-full border-pressing-secondary text-pressing-secondary hover:bg-pressing-secondary hover:text-white rounded-xl transition-all">
                      <Download className="h-4 w-4 mr-2" />
                      Télécharger PDF
                    </Button>
                    <Button variant="outline" size="sm" className="w-full border-pressing-accent2 text-pressing-accent2 hover:bg-pressing-accent2 hover:text-white rounded-xl transition-all">
                      <Send className="h-4 w-4 mr-2" />
                      Envoyer par email
                    </Button>
                    {facture.statut_paiement === 'non_paye' && (
                      <Button 
                        size="sm" 
                        className="w-full gradient-button text-white shadow-lg"
                        onClick={() => handlePaymentUpdate(facture.id)}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Marquer payée
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {filteredFactures.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">
              <FileText className="h-12 w-12 mx-auto mb-4" />
              <p className="text-lg font-medium">Aucune facture trouvée</p>
              <p className="text-sm">Essayez de modifier vos critères de recherche</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle>Résumé financier</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-pressing-background rounded-lg">
              <p className="text-2xl font-bold text-pressing-primary">
                {stats.chiffreAffaires.toLocaleString()} GNF
              </p>
              <p className="text-sm text-gray-600 mt-1">Chiffre d'affaires total</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">
                {(stats.chiffreAffaires - stats.montantEnAttente).toLocaleString()} GNF
              </p>
              <p className="text-sm text-gray-600 mt-1">Montant encaissé</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">
                {stats.montantEnAttente.toLocaleString()} GNF
              </p>
              <p className="text-sm text-gray-600 mt-1">En attente de paiement</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Modal Nouvelle Facture */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[900px] glass-effect border-0 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent flex items-center gap-2">
              <div className="p-2 bg-pressing-primary/10 rounded-lg">
                <Plus className="h-5 w-5 text-pressing-primary" />
              </div>
              Nouvelle Facture
            </DialogTitle>
            <DialogDescription className="text-gray-600">
              Créez une nouvelle facture en sélectionnant un client et des articles
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            {/* Informations facture */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="numeroFacture" className="text-sm font-medium text-gray-700">
                  Numéro de facture
                </Label>
                <Input
                  id="numeroFacture"
                  value={newFacture.numeroFacture}
                  readOnly
                  className="bg-gray-50 border-pressing-primary/20"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dateFacture" className="text-sm font-medium text-gray-700">
                  Date de facture *
                </Label>
                <Input
                  id="dateFacture"
                  type="date"
                  value={newFacture.dateFacture}
                  onChange={(e) => setNewFacture(prev => ({ ...prev, dateFacture: e.target.value }))}
                  className="border-pressing-primary/20 focus:border-pressing-primary"
                />
              </div>
            </div>

            {/* Sélection client */}
            <div className="space-y-2">
              <Label htmlFor="client" className="text-sm font-medium text-gray-700">
                Client *
              </Label>
              <Select value={selectedClient} onValueChange={setSelectedClient}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez un client" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.prenom} {client.nom} ({client.code_client})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sélection articles */}
            <div className="space-y-4">
              <Label className="text-sm font-medium text-gray-700">Articles disponibles</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-60 overflow-y-auto border border-gray-200 rounded-lg p-4">
                {articles.map((article) => (
                  <div key={article.id} className="flex items-center justify-between p-3 bg-white border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex-1">
                      <div className="font-medium text-sm">{article.designation}</div>
                      <div className="text-xs text-gray-500">{article.code_article}</div>
                      <div className="text-xs font-bold text-pressing-primary">{article.prix.toLocaleString()} GNF</div>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => addArticleToFacture(article)}
                      className="ml-2"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Articles sélectionnés */}
            {selectedArticles.length > 0 && (
              <div className="space-y-4">
                <Label className="text-sm font-medium text-gray-700">Articles sélectionnés</Label>
                <div className="space-y-2 border border-gray-200 rounded-lg p-4">
                  {selectedArticles.map((article) => (
                    <div key={article.id} className="flex items-center justify-between p-3 bg-pressing-background rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{article.designation}</div>
                        <div className="text-sm text-gray-600">{article.code_article}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => updateArticleQuantity(article.id, article.quantite - 1)}
                          >
                            -
                          </Button>
                          <span className="mx-2 font-medium">{article.quantite}</span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => updateArticleQuantity(article.id, article.quantite + 1)}
                          >
                            +
                          </Button>
                        </div>
                        <div className="text-right min-w-[80px]">
                          <div className="font-bold text-pressing-primary">{article.sousTotal.toLocaleString()} GNF</div>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => removeArticleFromFacture(article.id)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  {/* Total */}
                  <div className="border-t pt-3 mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Sous-total:</span>
                      <span>{selectedArticles.reduce((sum, a) => sum + a.sousTotal, 0).toLocaleString()} GNF</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>TVA (20%):</span>
                      <span>{(selectedArticles.reduce((sum, a) => sum + a.sousTotal, 0) * 0.20).toLocaleString()} GNF</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total TTC:</span>
                      <span className="text-pressing-primary">
                        {(selectedArticles.reduce((sum, a) => sum + a.sousTotal, 0) * 1.20).toLocaleString()} GNF
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button
              type="button"
              onClick={handleCreateFacture}
              className="gradient-button text-white border-0 shadow-lg"
              disabled={!selectedClient || selectedArticles.length === 0}
            >
              <Save className="h-4 w-4 mr-2" />
              Créer la facture
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}