'use client';

import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../../components/ui/dialog';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { genererCodeClient } from '../types/pressing';
import { Client } from '../types/pressing';
import { Search, Plus, Phone, Mail, MapPin, User, Calendar, Save, X, Eye } from 'lucide-react';

// Lazy loading pour ClientDetails seulement
const ClientDetails = lazy(() => import('./ClientDetails'));

export default function ClientsList() {
  console.log('ClientsList rendered');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [clients, setClients] = useState<Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newClient, setNewClient] = useState({
    prenom: '',
    nom: '',
    telephone: '',
    email: '',
    adresse: ''
  });

  // Charger les clients depuis l'API
  const loadClients = async () => {
    try {
      console.log('Loading clients from API...');
      const response = await fetch('/api/clients');
      if (response.ok) {
        const data = await response.json();
        console.log('Clients loaded from API:', data);
        
        // Mapper les données Supabase vers notre format Client
        const mappedClients: Client[] = data.map((client: any) => ({
          id: client.id,
          codeClient: client.code_client,
          prenom: client.prenom,
          nom: client.nom,
          telephone: client.telephone,
          email: client.email,
          adresse: client.adresse,
          dateCreation: new Date(client.created_at),
          nombreCommandes: 0,
          chiffreAffaires: 0,
        }));
        
        setClients(mappedClients);
      } else {
        console.error('Failed to load clients:', response.statusText);
      }
    } catch (error) {
      console.error('Error loading clients:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadClients();
  }, []);

  const filteredClients = clients.filter(client => 
    `${client.prenom} ${client.nom}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.codeClient.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.telephone.includes(searchTerm) ||
    client.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Fonction pour ajouter un nouveau client
  const handleAddClient = async () => {
    console.log('Adding new client:', newClient);
    
    if (!newClient.prenom.trim() || !newClient.nom.trim() || !newClient.telephone.trim()) {
      alert('Veuillez remplir au minimum le prénom, nom et téléphone');
      return;
    }

    try {
      // Générer le code client
      const codeClient = genererCodeClient(clients.length);
      
      const clientData = {
        code_client: codeClient,
        prenom: newClient.prenom.trim(),
        nom: newClient.nom.trim(),
        telephone: newClient.telephone.trim(),
        email: newClient.email.trim() || null,
        adresse: newClient.adresse.trim() || null,
      };

      console.log('Sending client data to API:', clientData);

      const response = await fetch('/api/clients', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(clientData),
      });

      if (response.ok) {
        const newClientFromAPI = await response.json();
        console.log('Client created successfully:', newClientFromAPI);
        
        // Recharger les clients
        await loadClients();
        
        setNewClient({ prenom: '', nom: '', telephone: '', email: '', adresse: '' });
        setIsAddModalOpen(false);
        
        alert(`Client ${codeClient} créé avec succès!`);
      } else {
        const errorData = await response.json();
        console.error('Failed to create client:', errorData);
        alert('Erreur lors de la création du client');
      }
    } catch (error) {
      console.error('Error creating client:', error);
      alert('Erreur lors de la création du client');
    }
  };

  // Fonction pour réinitialiser le formulaire
  const resetForm = () => {
    setNewClient({ prenom: '', nom: '', telephone: '', email: '', adresse: '' });
    setIsAddModalOpen(false);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent">
            Clients
          </h2>
          <p className="text-gray-600 mt-2 text-lg">Gérez votre base de clients avec élégance</p>
        </div>
        <Button 
          onClick={() => setIsAddModalOpen(true)}
          className="gradient-button w-full sm:w-auto text-white border-0 shadow-lg"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nouveau client
        </Button>
      </div>

      {/* Search */}
      <Card className="glass-effect border-0 card-hover">
        <CardContent className="p-6">
          <div className="relative">
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 p-1 bg-pressing-primary/10 rounded-lg">
              <Search className="h-4 w-4 text-pressing-primary" />
            </div>
            <Input
              type="text"
              placeholder="Rechercher par nom, code client, téléphone, email..."
              className="pl-12 border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {isLoading && (
        <Card className="glass-effect border-0">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pressing-primary mx-auto mb-4"></div>
            <p className="text-lg font-medium text-pressing-text">Chargement des clients...</p>
          </CardContent>
        </Card>
      )}

      {/* Clients Grid */}
      {!isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClients.map((client) => {
          return (
            <Card key={client.id} className="card-hover glass-effect border-0">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-pressing-primary/10 to-pressing-accent/10 rounded-xl flex items-center justify-center border border-pressing-primary/20">
                    <User className="h-6 w-6 text-pressing-primary" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg text-pressing-text">
                      {client.prenom} {client.nom}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono bg-pressing-secondary text-pressing-primary px-2 py-1 rounded-md">
                        {client.codeClient}
                      </span>
                      <p className="text-sm text-gray-500">
                        Depuis {new Date(client.dateCreation).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Contact Info */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>{client.telephone}</span>
                  </div>
                  
                  {client.email && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="h-4 w-4" />
                      <span className="truncate">{client.email}</span>
                    </div>
                  )}
                  
                  <div className="flex items-start gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-2">{client.adresse}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-3">
                  <Suspense fallback={
                    <Button variant="outline" size="sm" className="w-full border-pressing-primary text-pressing-primary opacity-50" disabled>
                      <Eye className="h-4 w-4 mr-1" />
                      Chargement...
                    </Button>
                  }>
                    <ClientDetails 
                      client={client}
                      trigger={
                        <Button variant="outline" size="sm" className="w-full border-pressing-primary text-pressing-primary hover:bg-pressing-primary hover:text-white rounded-xl transition-all">
                          <Eye className="h-4 w-4 mr-1" />
                          Voir détails
                        </Button>
                      }
                    />
                  </Suspense>
                </div>
              </CardContent>
            </Card>
          );
        })}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && filteredClients.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Search className="h-12 w-12 mx-auto mb-4" />
              <p className="text-lg font-medium">Aucun client trouvé</p>
              <p className="text-sm">Essayez de modifier votre recherche</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Stats */}
      <Card className="card-hover glass-effect border-0">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="p-2 bg-pressing-mint/10 rounded-lg">
              <User className="h-5 w-5 text-pressing-mint" />
            </div>
            Statistiques clients
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-6 bg-gradient-to-br from-pressing-primary/10 to-pressing-lavender/10 rounded-xl border border-pressing-primary/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-lavender bg-clip-text text-transparent">{clients.length}</p>
              <p className="text-sm text-gray-600 mt-2">Total clients</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-pressing-mint/10 to-pressing-accent/10 rounded-xl border border-pressing-mint/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-mint to-pressing-accent bg-clip-text text-transparent">
                {clients.length}
              </p>
              <p className="text-sm text-gray-600 mt-2">Clients actifs</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-pressing-accent2/10 to-orange-200 rounded-xl border border-pressing-accent2/20">
              <p className="text-3xl font-bold bg-gradient-to-r from-pressing-accent2 to-orange-500 bg-clip-text text-transparent">
                0 GNF
              </p>
              <p className="text-sm text-gray-600 mt-2">Panier moyen</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-purple-100 to-pressing-primary/10 rounded-xl border border-purple-200">
              <p className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pressing-primary bg-clip-text text-transparent">
                {clients.filter(c => c.email).length}
              </p>
              <p className="text-sm text-gray-600 mt-2">Avec email</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add Client Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-[600px] glass-effect border-0">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-pressing-primary to-pressing-accent2 bg-clip-text text-transparent flex items-center gap-2">
              <div className="p-2 bg-pressing-primary/10 rounded-lg">
                <Plus className="h-5 w-5 text-pressing-primary" />
              </div>
              Nouveau Client
            </DialogTitle>
            <DialogDescription className="text-gray-600">
              Ajoutez un nouveau client à votre base de données
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="prenom" className="text-sm font-medium text-gray-700">
                  Prénom *
                </Label>
                <Input
                  id="prenom"
                  value={newClient.prenom}
                  onChange={(e) => setNewClient(prev => ({ ...prev, prenom: e.target.value }))}
                  placeholder="Prénom du client"
                  className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="nom" className="text-sm font-medium text-gray-700">
                  Nom *
                </Label>
                <Input
                  id="nom"
                  value={newClient.nom}
                  onChange={(e) => setNewClient(prev => ({ ...prev, nom: e.target.value }))}
                  placeholder="Nom du client"
                  className="border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telephone" className="text-sm font-medium text-gray-700">
                  Téléphone *
                </Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                    <Phone className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input
                    id="telephone"
                    value={newClient.telephone}
                    onChange={(e) => setNewClient(prev => ({ ...prev, telephone: e.target.value }))}
                    placeholder="+224 XX XX XX XX"
                    className="pl-10 border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                  Email <span className="text-gray-400 font-normal">(optionnel)</span>
                </Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                    <Mail className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input
                    id="email"
                    type="email"
                    value={newClient.email}
                    onChange={(e) => setNewClient(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="email@exemple.com"
                    className="pl-10 border-pressing-primary/20 focus:border-pressing-primary rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="adresse" className="text-sm font-medium text-gray-700">
                Adresse <span className="text-gray-400 font-normal">(optionnel)</span>
              </Label>
              <div className="relative">
                <div className="absolute left-3 top-3">
                  <MapPin className="h-4 w-4 text-gray-400" />
                </div>
                <Textarea
                  id="adresse"
                  value={newClient.adresse}
                  onChange={(e) => setNewClient(prev => ({ ...prev, adresse: e.target.value }))}
                  placeholder="Adresse complète du client"
                  className="pl-10 border-pressing-primary/20 focus:border-pressing-primary rounded-xl min-h-[80px]"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              className="border-gray-300 text-gray-700 hover:bg-gray-50 rounded-xl"
            >
              <X className="h-4 w-4 mr-2" />
              Annuler
            </Button>
            <Button
              type="button"
              onClick={handleAddClient}
              className="gradient-button text-white border-0 shadow-lg"
            >
              <Save className="h-4 w-4 mr-2" />
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}