export interface Client {
  id: string;
  codeClient: string; // Code unique pour identifier le client (ex: LP-C001)
  nom: string;
  prenom: string;
  telephone: string;
  email?: string;
  adresse: string;
  dateCreation: Date;
  nombreCommandes?: number;
  chiffreAffaires?: number;
  notes?: string;
}

export interface Utilisateur {
  id: string;
  nom: string;
  prenom: string;
  email: string;
  motDePasse: string;
  role: 'admin' | 'employe' | 'gestionnaire';
  statut: 'actif' | 'inactif';
  dateCreation: Date;
  derniereConnexion?: Date;
  permissions: Permission[];
}

export interface Permission {
  id: string;
  nom: string;
  description: string;
  module: 'commandes' | 'clients' | 'facturation' | 'utilisateurs' | 'parametres' | 'rapports';
  actions: ('lire' | 'creer' | 'modifier' | 'supprimer')[];
}

export interface SessionUtilisateur {
  utilisateur: Utilisateur;
  token: string;
  dateExpiration: Date;
}

export interface Service {
  id: string;
  nom: string;
  prix: number;
  dureeJours: number;
  description?: string;
}

export interface Article {
  id: string;
  codeArticle: string; // Code unique pour identifier l'article (ex: LP-A001)
  designation: string;
  categorie: 'vetements' | 'accessoires' | 'linge' | 'chaussures' | 'cuir' | 'autres';
  prix: number;
  description?: string;
  couleur?: string;
  taille?: string;
  marque?: string;
  matiere?: string;
  etat?: 'neuf' | 'bon' | 'moyen' | 'usage';
  servicesPersonnalises?: ServicePersonnalise[]; // Services avec prix personnalisés pour cet article
  dateCreation: Date;
  dateModification: Date;
  actif: boolean;
}

export interface ServicePersonnalise {
  serviceId: string;
  nom: string;
  prixPersonnalise: number;
  actif: boolean;
}

export interface ArticleCommande {
  id: string;
  articleId: string;
  article: Article;
  serviceId: string;
  service: Service;
  quantite: number;
  prixUnitaireArticle: number; // Prix de l'article lui-même
  prixUnitaireService: number; // Prix du service appliqué
  sousTotal: number; // (prixUnitaireArticle + prixUnitaireService) * quantite
  notes?: string;
}

export interface Commande {
  id: string;
  clientId: string;
  client: Client;
  numeroCommande: string;
  dateDepot: Date;
  datePrevueRetrait: Date;
  dateRetrait?: Date;
  statut: 'en_attente' | 'en_cours' | 'pret' | 'retire' | 'annule';
  articles: ArticleCommande[];
  sousTotal: number;
  tva: number;
  total: number;
  payeAcompte: number;
  resteDu: number;
  modePaiement?: 'especes' | 'carte' | 'cheque' | 'virement';
  notes?: string;
}

export interface Facture {
  id: string;
  commandeId: string;
  commande: Commande;
  numeroFacture: string;
  dateFacture: Date;
  dateEcheance: Date;
  montantHT: number;
  tva: number;
  montantTTC: number;
  statut: 'en_attente' | 'payee' | 'en_retard';
  modePaiement?: 'especes' | 'carte' | 'cheque' | 'virement';
  notesFacture?: string;
}

export const SERVICES_DEFAULTS: Service[] = [
  { id: '1', nom: 'Nettoyage à sec', prix: 85000, dureeJours: 2, description: 'Nettoyage professionnel à sec' },
  { id: '2', nom: 'Repassage', prix: 35000, dureeJours: 1, description: 'Repassage professionnel' },
  { id: '3', nom: 'Lavage + Repassage', prix: 60000, dureeJours: 2, description: 'Service complet' },
  { id: '4', nom: 'Teinture', prix: 150000, dureeJours: 5, description: 'Teinture de vêtements' },
  { id: '5', nom: 'Retouche', prix: 120000, dureeJours: 3, description: 'Retouches diverses' },
];

export const STATUT_COULEURS = {
  en_attente: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  en_cours: 'bg-blue-100 text-blue-800 border-blue-200',
  pret: 'bg-green-100 text-green-800 border-green-200',
  retire: 'bg-gray-100 text-gray-800 border-gray-200',
  annule: 'bg-red-100 text-red-800 border-red-200',
};

export const STATUT_LABELS = {
  en_attente: 'En attente',
  en_cours: 'En cours',
  pret: 'Prêt',
  retire: 'Retiré',
  annule: 'Annulé',
};

export const ROLES_LABELS = {
  admin: 'Administrateur',
  employe: 'Employé',
  gestionnaire: 'Gestionnaire',
};

export const PERMISSIONS_DEFAUT: Permission[] = [
  {
    id: 'commandes-full',
    nom: 'Gestion des commandes',
    description: 'Accès complet aux commandes',
    module: 'commandes',
    actions: ['lire', 'creer', 'modifier', 'supprimer']
  },
  {
    id: 'commandes-read',
    nom: 'Lecture des commandes',
    description: 'Lecture seule des commandes',
    module: 'commandes',
    actions: ['lire']
  },
  {
    id: 'clients-full',
    nom: 'Gestion des clients',
    description: 'Accès complet aux clients',
    module: 'clients',
    actions: ['lire', 'creer', 'modifier', 'supprimer']
  },
  {
    id: 'facturation-full',
    nom: 'Gestion de la facturation',
    description: 'Accès complet à la facturation',
    module: 'facturation',
    actions: ['lire', 'creer', 'modifier', 'supprimer']
  },
  {
    id: 'utilisateurs-full',
    nom: 'Gestion des utilisateurs',
    description: 'Accès complet aux utilisateurs (Admin seulement)',
    module: 'utilisateurs',
    actions: ['lire', 'creer', 'modifier', 'supprimer']
  },
  {
    id: 'parametres-full',
    nom: 'Gestion des paramètres',
    description: 'Accès complet aux paramètres',
    module: 'parametres',
    actions: ['lire', 'creer', 'modifier', 'supprimer']
  }
];

// Fonction utilitaire pour générer un code client unique
export const genererCodeClient = (index: number): string => {
  const paddedIndex = (index + 1).toString().padStart(3, '0');
  return `LP-C${paddedIndex}`;
};

// Fonction utilitaire pour générer un code article unique
export const genererCodeArticle = (index: number): string => {
  const paddedIndex = (index + 1).toString().padStart(3, '0');
  return `LP-A${paddedIndex}`;
};

export const CATEGORIES_ARTICLES = {
  vetements: 'Vêtements',
  accessoires: 'Accessoires',
  linge: 'Linge de maison',
  chaussures: 'Chaussures', 
  cuir: 'Articles en cuir',
  autres: 'Autres'
};

export const COULEURS_CATEGORIES = {
  vetements: 'bg-blue-100 text-blue-800 border-blue-200',
  accessoires: 'bg-purple-100 text-purple-800 border-purple-200',
  linge: 'bg-green-100 text-green-800 border-green-200',
  chaussures: 'bg-orange-100 text-orange-800 border-orange-200',
  cuir: 'bg-amber-100 text-amber-800 border-amber-200',
  autres: 'bg-gray-100 text-gray-800 border-gray-200'
};