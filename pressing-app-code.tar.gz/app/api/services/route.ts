import { NextResponse } from 'next/server';
import { supabase } from '../../lib/supabase';

export async function GET() {
  try {
    const { data: services, error } = await supabase
      .from('services')
      .select('*')
      .order('nom', { ascending: true });

    if (error) throw error;

    console.log('Services récupérés:', services);
    return NextResponse.json(services);
  } catch (error) {
    console.error('Erreur lors de la récupération des services:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Nouveau service à créer:', body);

    const { data: service, error } = await supabase
      .from('services')
      .insert([body])
      .select()
      .single();

    if (error) throw error;

    console.log('Service créé:', service);
    return NextResponse.json(service, { status: 201 });
  } catch (error) {
    console.error('Erreur lors de la création du service:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...updateData } = body;
    console.log('Service à modifier:', id, updateData);

    const { data: service, error } = await supabase
      .from('services')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    console.log('Service modifié:', service);
    return NextResponse.json(service);
  } catch (error) {
    console.error('Erreur lors de la modification du service:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }

    console.log('Service à supprimer:', id);

    const { error } = await supabase
      .from('services')
      .delete()
      .eq('id', id);

    if (error) throw error;

    console.log('Service supprimé:', id);
    return NextResponse.json({ message: 'Service supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du service:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}