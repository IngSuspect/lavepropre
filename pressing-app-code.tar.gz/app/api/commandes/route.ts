import { NextResponse } from 'next/server';
import { supabase } from '../../lib/supabase';

export async function GET() {
  try {
    const { data: commandes, error } = await supabase
      .from('commandes')
      .select(`
        *,
        clients(nom, prenom),
        articles(nom, prix)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;

    console.log('Commandes récupérées:', commandes);
    return NextResponse.json(commandes);
  } catch (error) {
    console.error('Erreur lors de la récupération des commandes:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Nouvelle commande à créer:', body);

    const { data: commande, error } = await supabase
      .from('commandes')
      .insert([body])
      .select(`
        *,
        clients(nom, prenom),
        articles(nom, prix)
      `)
      .single();

    if (error) throw error;

    console.log('Commande créée:', commande);
    return NextResponse.json(commande, { status: 201 });
  } catch (error) {
    console.error('Erreur lors de la création de la commande:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...updateData } = body;
    console.log('Commande à modifier:', id, updateData);

    const { data: commande, error } = await supabase
      .from('commandes')
      .update(updateData)
      .eq('id', id)
      .select(`
        *,
        clients(nom, prenom),
        articles(nom, prix)
      `)
      .single();

    if (error) throw error;

    console.log('Commande modifiée:', commande);
    return NextResponse.json(commande);
  } catch (error) {
    console.error('Erreur lors de la modification de la commande:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }

    console.log('Commande à supprimer:', id);

    const { error } = await supabase
      .from('commandes')
      .delete()
      .eq('id', id);

    if (error) throw error;

    console.log('Commande supprimée:', id);
    return NextResponse.json({ message: 'Commande supprimée avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression de la commande:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}