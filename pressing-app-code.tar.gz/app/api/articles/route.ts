import { NextResponse } from 'next/server';
import { supabase } from '../../lib/supabase';

export async function GET() {
  try {
    const { data: articles, error } = await supabase
      .from('articles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;

    console.log('Articles récupérés:', articles);
    return NextResponse.json(articles);
  } catch (error) {
    console.error('Erreur lors de la récupération des articles:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Nouvel article à créer:', body);

    // Mapper les données pour correspondre au schéma de la DB
    const articleData = {
      code_article: body.code_article,
      designation: body.designation,
      prix: body.prix,
      services_personnalises: body.servicesPersonnalises || body.services_personnalises || {}
    };

    console.log('Données mappées pour la DB:', articleData);

    const { data: article, error } = await supabase
      .from('articles')
      .insert([articleData])
      .select()
      .single();

    if (error) throw error;

    console.log('Article créé:', article);
    return NextResponse.json(article, { status: 201 });
  } catch (error) {
    console.error('Erreur lors de la création de l\'article:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    console.log('Article à modifier:', id, data);

    // Mapper les données pour correspondre au schéma de la DB
    const updateData = {
      code_article: data.code_article,
      designation: data.designation,
      prix: data.prix,
      services_personnalises: data.servicesPersonnalises || data.services_personnalises || {}
    };

    console.log('Données de mise à jour mappées:', updateData);

    const { data: article, error } = await supabase
      .from('articles')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    console.log('Article modifié:', article);
    return NextResponse.json(article);
  } catch (error) {
    console.error('Erreur lors de la modification de l\'article:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }

    console.log('Article à supprimer:', id);

    const { error } = await supabase
      .from('articles')
      .delete()
      .eq('id', id);

    if (error) throw error;

    console.log('Article supprimé:', id);
    return NextResponse.json({ message: 'Article supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression de l\'article:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}