import { NextResponse } from 'next/server';
import { supabase } from '../../lib/supabase';

export async function GET() {
  try {
    console.log('Fetching utilisateurs from Supabase...');
    
    const { data: utilisateurs, error } = await supabase
      .from('utilisateurs')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json(
        { error: 'Erreur lors de la récupération des utilisateurs' },
        { status: 500 }
      );
    }

    console.log('Utilisateurs fetched successfully:', utilisateurs?.length || 0);
    return NextResponse.json(utilisateurs || []);
    
  } catch (error) {
    console.error('Erreur lors de la récupération des utilisateurs:', error);
    return NextResponse.json(
      { error: 'Erreur serveur' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Creating new utilisateur:', body);

    const { data: utilisateur, error } = await supabase
      .from('utilisateurs')
      .insert([{
        nom: body.nom,
        prenom: body.prenom,
        email: body.email,
        mot_de_passe: body.motDePasse,
        role: body.role,
        statut: body.statut || 'actif',
        permissions: body.permissions || []
      }])
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json(
        { error: 'Erreur lors de la création de l\'utilisateur' },
        { status: 500 }
      );
    }

    console.log('Utilisateur created successfully:', utilisateur);
    return NextResponse.json(utilisateur, { status: 201 });
    
  } catch (error) {
    console.error('Erreur lors de la création de l\'utilisateur:', error);
    return NextResponse.json(
      { error: 'Erreur serveur' },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    console.log('Updating utilisateur:', body);

    const updateData: any = {
      nom: body.nom,
      prenom: body.prenom,
      email: body.email,
      role: body.role,
      statut: body.statut,
      permissions: body.permissions
    };

    // Only update password if provided
    if (body.motDePasse && body.motDePasse.trim()) {
      updateData.mot_de_passe = body.motDePasse;
    }

    const { data: utilisateur, error } = await supabase
      .from('utilisateurs')
      .update(updateData)
      .eq('id', body.id)
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json(
        { error: 'Erreur lors de la mise à jour de l\'utilisateur' },
        { status: 500 }
      );
    }

    console.log('Utilisateur updated successfully:', utilisateur);
    return NextResponse.json(utilisateur);
    
  } catch (error) {
    console.error('Erreur lors de la mise à jour de l\'utilisateur:', error);
    return NextResponse.json(
      { error: 'Erreur serveur' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }

    console.log('Deleting utilisateur:', id);

    const { error } = await supabase
      .from('utilisateurs')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json(
        { error: 'Erreur lors de la suppression de l\'utilisateur' },
        { status: 500 }
      );
    }

    console.log('Utilisateur deleted successfully:', id);
    return NextResponse.json({ message: 'Utilisateur supprimé avec succès' });
    
  } catch (error) {
    console.error('Erreur lors de la suppression de l\'utilisateur:', error);
    return NextResponse.json(
      { error: 'Erreur serveur' },
      { status: 500 }
    );
  }
}