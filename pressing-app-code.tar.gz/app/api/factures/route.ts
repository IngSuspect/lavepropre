import { NextResponse } from 'next/server';
import { supabase } from '../../lib/supabase';

export async function GET() {
  try {
    const { data: factures, error } = await supabase
      .from('factures')
      .select(`
        *,
        clients(nom, prenom, email, telephone, code_client)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;

    console.log('Factures récupérées:', factures);
    return NextResponse.json(factures);
  } catch (error) {
    console.error('Erreur lors de la récupération des factures:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log('Nouvelle facture à créer:', body);

    const { data: facture, error } = await supabase
      .from('factures')
      .insert([body])
      .select(`
        *,
        clients(nom, prenom, email, telephone, code_client)
      `)
      .single();

    if (error) throw error;

    console.log('Facture créée:', facture);
    return NextResponse.json(facture, { status: 201 });
  } catch (error) {
    console.error('Erreur lors de la création de la facture:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...updateData } = body;
    console.log('Facture à modifier:', id, updateData);

    const { data: facture, error } = await supabase
      .from('factures')
      .update(updateData)
      .eq('id', id)
      .select(`
        *,
        clients(nom, prenom, email, telephone, code_client)
      `)
      .single();

    if (error) throw error;

    console.log('Facture modifiée:', facture);
    return NextResponse.json(facture);
  } catch (error) {
    console.error('Erreur lors de la modification de la facture:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }

    console.log('Facture à supprimer:', id);

    const { error } = await supabase
      .from('factures')
      .delete()
      .eq('id', id);

    if (error) throw error;

    console.log('Facture supprimée:', id);
    return NextResponse.json({ message: 'Facture supprimée avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression de la facture:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}