import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xiaweiotalfkxqiseyeh.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhpYXdlaW90YWxma3hxaXNleWVoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAwODkyOTgsImV4cCI6MjA2NTY2NTI5OH0.r9El8Nsnj9uXS8JFOFRrN8d-oyyImje9bnIbOBEs47E'

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 2
    }
  }
})

console.log('✅ Supabase configuré avec:', { url: supabaseUrl, keyPresent: !!supabaseAnonKey })

// Fonction helper pour vérifier si Supabase est configuré
export const isSupabaseConfigured = () => true

// Types pour la base de données
export interface Database {
  public: {
    Tables: {
      clients: {
        Row: {
          id: string
          code_client: string
          nom: string
          prenom: string
          telephone: string
          adresse: string
          email?: string
          created_at: string
        }
        Insert: {
          id?: string
          code_client: string
          nom: string
          prenom: string
          telephone: string
          adresse: string
          email?: string
          created_at?: string
        }
        Update: {
          id?: string
          code_client?: string
          nom?: string
          prenom?: string
          telephone?: string
          adresse?: string
          email?: string
          created_at?: string
        }
      }
      articles: {
        Row: {
          id: string
          code_article: string
          designation: string
          prix: number
          services_personnalises: any
          created_at: string
        }
        Insert: {
          id?: string
          code_article: string
          designation: string
          prix: number
          services_personnalises?: any
          created_at?: string
        }
        Update: {
          id?: string
          code_article?: string
          designation?: string
          prix?: number
          services_personnalises?: any
          created_at?: string
        }
      }
      commandes: {
        Row: {
          id: string
          numero_commande: string
          client_id: string
          date_commande: string
          statut: string
          total: number
          created_at: string
        }
        Insert: {
          id?: string
          numero_commande: string
          client_id: string
          date_commande: string
          statut?: string
          total: number
          created_at?: string
        }
        Update: {
          id?: string
          numero_commande?: string
          client_id?: string
          date_commande?: string
          statut?: string
          total?: number
          created_at?: string
        }
      }
      articles_commandes: {
        Row: {
          id: string
          commande_id: string
          article_id: string
          quantite: number
          prix_unitaire: number
          services_utilises: any
          created_at: string
        }
        Insert: {
          id?: string
          commande_id: string
          article_id: string
          quantite: number
          prix_unitaire: number
          services_utilises?: any
          created_at?: string
        }
        Update: {
          id?: string
          commande_id?: string
          article_id?: string
          quantite?: number
          prix_unitaire?: number
          services_utilises?: any
          created_at?: string
        }
      }
      factures: {
        Row: {
          id: string
          numero_facture: string
          commande_id: string
          client_id: string
          date_facture: string
          montant_total: number
          statut_paiement: string
          created_at: string
        }
        Insert: {
          id?: string
          numero_facture: string
          commande_id: string
          client_id: string
          date_facture: string
          montant_total: number
          statut_paiement?: string
          created_at?: string
        }
        Update: {
          id?: string
          numero_facture?: string
          commande_id?: string
          client_id?: string
          date_facture?: string
          montant_total?: number
          statut_paiement?: string
          created_at?: string
        }
      }
      utilisateurs: {
        Row: {
          id: string
          nom: string
          prenom: string
          email: string
          role: string
          permissions: any
          actif: boolean
          created_at: string
        }
        Insert: {
          id?: string
          nom: string
          prenom: string
          email: string
          role?: string
          permissions?: any
          actif?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          nom?: string
          prenom?: string
          email?: string
          role?: string
          permissions?: any
          actif?: boolean
          created_at?: string
        }
      }
    }
  }
}