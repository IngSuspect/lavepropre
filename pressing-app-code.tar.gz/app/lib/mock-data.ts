import { Client, Commande, Service, Utilisateur, Facture, Article, SERVICES_DEFAULTS, PERMISSIONS_DEFAUT, genererCodeClient, genererCodeArticle } from '../types/pressing';

export const mockClients: Client[] = [
  {
    id: '1',
    codeClient: genererCodeClient(0),
    nom: 'Dupont',
    prenom: 'Marie',
    telephone: '+224 628 45 67 89',
    email: 'marie.dupont@email.com',
    adresse: 'Quartier Almamya, Kaloum, Conakry',
    dateCreation: new Date('2024-01-15'),
    nombreCommandes: 3,
    chiffreAffaires: 450000,
    notes: 'Cliente fidèle depuis 2024'
  },
  {
    id: '2',
    codeClient: genererCodeClient(1),
    nom: 'Martin',
    prenom: 'Pierre',
    telephone: '+224 622 98 76 54',
    email: 'pierre.martin@email.com',
    adresse: 'Quartier Kipé, Ratoma, Conakry',
    dateCreation: new Date('2024-02-20'),
    nombreCommandes: 1,
    chiffreAffaires: 72000,
    notes: 'Nouveau client'
  },
  {
    id: '3',
    codeClient: genererCodeClient(2),
    nom: 'Bernard',
    prenom: 'Sophie',
    telephone: '+224 611 22 33 44',
    adresse: 'Quartier Hamdallaye, Dixinn, Conakry',
    dateCreation: new Date('2024-03-10'),
    nombreCommandes: 2,
    chiffreAffaires: 330000,
    notes: 'Commandes régulières de vêtements de qualité'
  },
];

export const mockServices: Service[] = SERVICES_DEFAULTS;

export const mockUtilisateurs: Utilisateur[] = [
  {
    id: '1',
    nom: 'Admin',
    prenom: 'Super',
    email: 'admin@lavepropre.com',
    motDePasse: 'admin123', // En production, ce serait haché
    role: 'admin',
    statut: 'actif',
    dateCreation: new Date('2024-01-01'),
    derniereConnexion: new Date(),
    permissions: PERMISSIONS_DEFAUT // Admin a toutes les permissions
  },
  {
    id: '2',
    nom: 'Traore',
    prenom: 'Aminata',
    email: 'aminata@lavepropre.com',
    motDePasse: 'employe123',
    role: 'gestionnaire',
    statut: 'actif',
    dateCreation: new Date('2024-02-15'),
    derniereConnexion: new Date('2024-06-13'),
    permissions: [
      PERMISSIONS_DEFAUT.find(p => p.id === 'commandes-full')!,
      PERMISSIONS_DEFAUT.find(p => p.id === 'clients-full')!,
      PERMISSIONS_DEFAUT.find(p => p.id === 'facturation-full')!
    ]
  },
  {
    id: '3',
    nom: 'Camara',
    prenom: 'Ibrahima',
    email: 'ibrahima@lavepropre.com',
    motDePasse: 'employe456',
    role: 'employe',
    statut: 'actif',
    dateCreation: new Date('2024-03-20'),
    derniereConnexion: new Date('2024-06-12'),
    permissions: [
      PERMISSIONS_DEFAUT.find(p => p.id === 'commandes-read')!,
      PERMISSIONS_DEFAUT.find(p => p.id === 'clients-full')!
    ]
  }
];

// Simulation d'une session utilisateur active
export let sessionActive: { utilisateur: Utilisateur; token: string; dateExpiration: Date } | null = null;

export const connexionUtilisateur = (email: string, motDePasse: string) => {
  console.log('Tentative de connexion:', email);
  
  const utilisateur = mockUtilisateurs.find(u => u.email === email && u.motDePasse === motDePasse && u.statut === 'actif');
  
  if (utilisateur) {
    const token = 'token-' + Math.random().toString(36).substr(2, 9);
    const dateExpiration = new Date();
    dateExpiration.setHours(dateExpiration.getHours() + 8); // Session de 8h
    
    sessionActive = {
      utilisateur: { ...utilisateur, derniereConnexion: new Date() },
      token,
      dateExpiration
    };
    
    console.log('Connexion réussie pour:', utilisateur.prenom, utilisateur.nom);
    return sessionActive;
  }
  
  console.log('Échec de connexion pour:', email);
  return null;
};

export const deconnexionUtilisateur = () => {
  console.log('Déconnexion utilisateur');
  sessionActive = null;
};

export const obtenirSessionActive = () => {
  if (sessionActive && sessionActive.dateExpiration > new Date()) {
    return sessionActive;
  }
  return null;
};

// Mock data pour les articles - définis en premier pour être référencés dans les commandes
export const mockArticles: Article[] = [
  {
    id: '1',
    codeArticle: genererCodeArticle(0),
    designation: 'Chemise homme classique',
    categorie: 'vetements',
    prix: 5000,
    description: 'Chemise en coton, col classique',
    couleur: 'Blanc',
    taille: 'M',
    marque: 'Standard',
    matiere: 'Coton',
    etat: 'bon',
    dateCreation: new Date('2024-01-15'),
    dateModification: new Date('2024-01-15'),
    actif: true
  },
  {
    id: '2', 
    codeArticle: genererCodeArticle(1),
    designation: 'Pantalon homme',
    categorie: 'vetements',
    prix: 9000,
    description: 'Pantalon en toile, coupe droite',
    couleur: 'Noir',
    taille: 'L',
    marque: 'Standard',
    matiere: 'Toile',
    etat: 'bon',
    dateCreation: new Date('2024-01-16'),
    dateModification: new Date('2024-01-16'),
    actif: true
  },
  {
    id: '3',
    codeArticle: genererCodeArticle(2),
    designation: 'Robe femme élégante',
    categorie: 'vetements',
    prix: 12000,
    description: 'Robe de soirée, tissu délicat',
    couleur: 'Rouge',
    taille: 'S',
    marque: 'Élégance',
    matiere: 'Soie',
    etat: 'neuf',
    dateCreation: new Date('2024-01-17'),
    dateModification: new Date('2024-01-17'),
    actif: true
  },
  {
    id: '4',
    codeArticle: genererCodeArticle(3),
    designation: 'Veste en cuir',
    categorie: 'cuir',
    prix: 25000,
    description: 'Veste en cuir véritable, nettoyage spécialisé',
    couleur: 'Marron',
    taille: 'L',
    marque: 'Leather Plus',
    matiere: 'Cuir',
    etat: 'bon',
    dateCreation: new Date('2024-01-18'),
    dateModification: new Date('2024-01-18'),
    actif: true
  },
  {
    id: '5',
    codeArticle: genererCodeArticle(4),
    designation: 'Chaussures en cuir',
    categorie: 'chaussures',
    prix: 8000,
    description: 'Chaussures de ville, cuir vernis',
    couleur: 'Noir',
    taille: '42',
    marque: 'Classic',
    matiere: 'Cuir',
    etat: 'bon',
    dateCreation: new Date('2024-01-19'),
    dateModification: new Date('2024-01-19'),
    actif: true
  },
  {
    id: '6',
    codeArticle: genererCodeArticle(5),
    designation: 'Drap de lit',
    categorie: 'linge',
    prix: 6000,
    description: 'Drap de lit coton, 200x200cm',
    couleur: 'Blanc',
    taille: '200x200',
    marque: 'Confort',
    matiere: 'Coton',
    etat: 'bon',
    dateCreation: new Date('2024-01-20'),
    dateModification: new Date('2024-01-20'),
    actif: true
  },
  {
    id: '7',
    codeArticle: genererCodeArticle(6),
    designation: 'Sac à main',
    categorie: 'accessoires',
    prix: 15000,
    description: 'Sac à main en cuir, nettoyage délicat',
    couleur: 'Beige',
    marque: 'Fashion',
    matiere: 'Cuir',
    etat: 'bon',
    dateCreation: new Date('2024-01-21'),
    dateModification: new Date('2024-01-21'),
    actif: true
  },
  {
    id: '8',
    codeArticle: genererCodeArticle(7),
    designation: 'Costume complet',
    categorie: 'vetements',
    prix: 18000,
    description: 'Costume 2 pièces, tissu de qualité',
    couleur: 'Gris',
    taille: 'M',
    marque: 'Business',
    matiere: 'Laine',
    etat: 'neuf',
    dateCreation: new Date('2024-01-22'),
    dateModification: new Date('2024-01-22'),
    actif: true
  }
];

// Commandes avec relations articles synchronisées
export const mockCommandes: Commande[] = [
  {
    id: '1',
    clientId: '1',
    client: mockClients[0],
    numeroCommande: 'CMD-2024-001',
    dateDepot: new Date('2024-06-10'),
    datePrevueRetrait: new Date('2024-06-12'),
    statut: 'en_cours',
    articles: [
      {
        id: '1-1',
        articleId: '8',
        article: mockArticles[7], // Costume complet
        serviceId: '1',
        service: mockServices[0], // Nettoyage à sec
        quantite: 1,
        prixUnitaireArticle: 18000, // Prix du costume
        prixUnitaireService: 85000, // Prix du nettoyage à sec
        sousTotal: 103000, // (18000 + 85000) * 1
        notes: 'Costume gris 2 pièces - nettoyage urgent',
      },
      {
        id: '1-2',
        articleId: '1',
        article: mockArticles[0], // Chemise homme classique
        serviceId: '2',
        service: mockServices[1], // Repassage
        quantite: 3,
        prixUnitaireArticle: 5000, // Prix chemise
        prixUnitaireService: 35000, // Prix repassage
        sousTotal: 120000, // (5000 + 35000) * 3
        notes: 'Chemises blanches col classique',
      },
    ],
    sousTotal: 223000,
    tva: 44600, // 20% de TVA
    total: 267600,
    payeAcompte: 100000,
    resteDu: 167600,
    modePaiement: 'especes',
  },
  {
    id: '2',
    clientId: '2',
    client: mockClients[1],
    numeroCommande: 'CMD-2024-002',
    dateDepot: new Date('2024-06-11'),
    datePrevueRetrait: new Date('2024-06-13'),
    statut: 'pret',
    articles: [
      {
        id: '2-1',
        articleId: '3',
        article: mockArticles[2], // Robe femme élégante
        serviceId: '3',
        service: mockServices[2], // Lavage + Repassage
        quantite: 1,
        prixUnitaireArticle: 12000, // Prix de la robe
        prixUnitaireService: 60000, // Prix lavage + repassage
        sousTotal: 72000, // (12000 + 60000) * 1
        notes: 'Robe rouge en soie - traitement délicat',
      },
    ],
    sousTotal: 72000,
    tva: 14400, // 20% de TVA
    total: 86400,
    payeAcompte: 0,
    resteDu: 86400,
  },
  {
    id: '3',
    clientId: '3',
    client: mockClients[2],
    numeroCommande: 'CMD-2024-003',
    dateDepot: new Date('2024-06-12'),
    datePrevueRetrait: new Date('2024-06-17'),
    statut: 'en_attente',
    articles: [
      {
        id: '3-1',
        articleId: '4',
        article: mockArticles[3], // Veste en cuir
        serviceId: '4',
        service: mockServices[3], // Teinture
        quantite: 1,
        prixUnitaireArticle: 25000, // Prix de la veste
        prixUnitaireService: 150000, // Prix teinture
        sousTotal: 175000, // (25000 + 150000) * 1
        notes: 'Veste cuir marron - teinture vers noir',
      },
      {
        id: '3-2',
        articleId: '7',
        article: mockArticles[6], // Sac à main
        serviceId: '1',
        service: mockServices[0], // Nettoyage à sec
        quantite: 1,
        prixUnitaireArticle: 15000, // Prix du sac
        prixUnitaireService: 85000, // Prix nettoyage
        sousTotal: 100000, // (15000 + 85000) * 1
        notes: 'Sac beige en cuir - nettoyage délicat',
      },
    ],
    sousTotal: 275000,
    tva: 55000, // 20% de TVA
    total: 330000,
    payeAcompte: 50000,
    resteDu: 280000,
    modePaiement: 'carte',
  },
];

// Factures avec relation client et articles synchronisée
export const mockFactures: Facture[] = [
  {
    id: 'FAC-001',
    commandeId: '1',
    commande: mockCommandes[0],
    numeroFacture: 'FAC-2024-001',
    dateFacture: new Date('2024-06-10'),
    dateEcheance: new Date('2024-07-10'),
    montantHT: 223000,
    tva: 44600,
    montantTTC: 267600,
    statut: 'en_attente',
    modePaiement: 'especes',
    notesFacture: 'Facture pour costume complet (LP-A008) + 3 chemises (LP-A001) - Nettoyage à sec + Repassage'
  },
  {
    id: 'FAC-002',
    commandeId: '2',
    commande: mockCommandes[1],
    numeroFacture: 'FAC-2024-002',
    dateFacture: new Date('2024-06-11'),
    dateEcheance: new Date('2024-07-11'),
    montantHT: 72000,
    tva: 14400,
    montantTTC: 86400,
    statut: 'payee',
    modePaiement: 'carte',
    notesFacture: 'Facture pour robe élégante rouge (LP-A003) - Lavage + Repassage délicat'
  },
  {
    id: 'FAC-003',
    commandeId: '3',
    commande: mockCommandes[2],
    numeroFacture: 'FAC-2024-003',
    dateFacture: new Date('2024-06-12'),
    dateEcheance: new Date('2024-07-12'),
    montantHT: 275000,
    tva: 55000,
    montantTTC: 330000,
    statut: 'en_attente',
    modePaiement: 'carte',
    notesFacture: 'Facture pour veste cuir (LP-A004) teinture + sac à main (LP-A007) nettoyage'
  }
];