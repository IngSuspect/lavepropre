import "./globals.css";
import { MacalySandboxBridge } from '../.sandbox/sandbox-bridge';
import type { Metadata } from "next";
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "LAVE PROPRE PRESSING - Gestion de Pressing",
  description: "Système complet de gestion de pressing avec facturation intégrée",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
        <MacalySandboxBridge><body className={inter.className}>{children}</body></MacalySandboxBridge>
    </html>
  );
}