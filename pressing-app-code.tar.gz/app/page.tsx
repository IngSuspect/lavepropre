'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';

import ClientsList from './components/ClientsList';
import ArticlesList from './components/ArticlesList';
import Facturation from './components/Facturation';
import Settings from './components/Settings';
import Connexion from './components/Connexion';
import GestionUtilisateurs from './components/GestionUtilisateurs';
import { Toaster } from '../components/ui/toaster';
import { obtenirSessionActive, deconnexionUtilisateur } from './lib/mock-data';
import { SessionUtilisateur } from './types/pressing';

// Composant de chargement
const LoadingSpinner = () => (
  <div className="p-6 flex items-center justify-center min-h-[400px]">
    <div className="flex items-center gap-3">
      <div className="w-6 h-6 border-2 border-pressing-primary border-t-transparent rounded-full animate-spin"></div>
      <span className="text-pressing-primary font-medium">Chargement...</span>
    </div>
  </div>
);

const VIEW_TITLES = {
  dashboard: 'Tableau de bord',
  clients: 'Clients',
  articles: 'Articles',
  factures: 'Facturation',
  utilisateurs: 'Gestion des utilisateurs',
  settings: 'Paramètres',
};

export default function Home() {
  console.log('Home component rendering');
  
  const [currentView, setCurrentView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    // Vérifier s'il y a une session active au chargement
    const sessionActive = obtenirSessionActive();
    if (sessionActive) {
      setSession(sessionActive);
    }
    setChargement(false);
  }, []);

  const gererConnexion = (nouvelleSession: any) => {
    console.log('Nouvelle session:', nouvelleSession);
    setSession(nouvelleSession);
  };

  const gererDeconnexion = () => {
    console.log('Déconnexion utilisateur');
    deconnexionUtilisateur();
    setSession(null);
    setCurrentView('dashboard');
  };

  const handleViewChange = (view: string) => {
    console.log('View changing to:', view);
    setCurrentView(view);
  };

  const handleSidebarToggle = () => {
    console.log('Sidebar toggle');
    setSidebarOpen(!sidebarOpen);
  };

  const renderCurrentView = () => {
    console.log('Rendering view:', currentView);
    
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onViewChange={handleViewChange} />;

      case 'clients':
        return <ClientsList />;
      case 'articles':
        return <ArticlesList />;
      case 'factures':
        return <Facturation />;
      case 'utilisateurs':
        return <GestionUtilisateurs />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onViewChange={handleViewChange} />;
    }
  };

  // Afficher l'écran de connexion si pas de session
  if (chargement) {
    return (
      <div className="min-h-screen bg-pressing-background flex items-center justify-center">
        <div className="text-pressing-primary">Chargement...</div>
      </div>
    );
  }

  if (!session) {
    return <Connexion onConnexion={gererConnexion} />;
  }

  return (
    <div className="min-h-screen bg-pressing-background">
      <div className="flex">
        {/* Sidebar */}
        <Sidebar
          currentView={currentView}
          onViewChange={handleViewChange}
          isOpen={sidebarOpen}
          onToggle={handleSidebarToggle}
          utilisateur={session.utilisateur}
          onDeconnexion={gererDeconnexion}
        />
        
        {/* Main Content */}
        <div className="flex-1 lg:ml-0">
          <Header
            onMenuToggle={handleSidebarToggle}
            title={VIEW_TITLES[currentView as keyof typeof VIEW_TITLES]}
            utilisateur={session.utilisateur}
            onDeconnexion={gererDeconnexion}
          />
          
          <main className="min-h-[calc(100vh-4rem)]">
            {renderCurrentView()}
          </main>
        </div>
      </div>
      
      <Toaster />
    </div>
  );
}